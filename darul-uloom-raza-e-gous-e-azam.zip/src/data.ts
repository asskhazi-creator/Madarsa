import { TranslationDict, Course, Facility, DocumentItem, Testimonial, GalleryItem, Announcement, PrayerTime } from './types';

export const translations: Record<'en' | 'ur', TranslationDict> = {
  en: {
    schoolName: "Darul Uloom Raza-E-Gous-E-Azam",
    locationDetails: "Taj Nagar, Haveri, Karnataka, India",
    navHome: "Home",
    navAbout: "About Us",
    navCourses: "Courses Offered",
    navFacilities: "Facilities",
    navGallery: "Photo Gallery",
    navDocuments: "Documents & Reports",
    navDonation: "Donations",
    navAnnouncements: "Announcements",
    navContact: "Contact Us",
    regNumber: "Reg No: KAR/HVR/786/2004",
    callUs: "Call Admin",
    whatsAppButton: "WhatsApp",
    admissionOpen: "Admission Open (2026 - 2027)",
    donateNow: "Donate Now (Fidya/Zakat/Sadaqah)",
    prayerTimesTitle: "Daily Congregational Prayer Timings",
    announcementsTitle: "Important Announcements",
    aboutTitle: "About Our Institution",
    aboutSubtitle: "Fostering Islamic character, rigorous academic scholarship, and community leadership.",
    aboutHistoryTitle: "Nurturing faith & knowledge for decades",
    aboutHistoryText: "Established with a pious vision, Darul Uloom Raza-E-Gous-E-Azam has been a beacon of orthodox Islamic scholarship and spiritual nurture in Karnataka. Named after Hazrat Gous-E-Azam (Sheikh Abdul Qadir Jilani), we are dedicated to preserving correct theological doctrine (Ahl-as-Sunnah Wal-Jama'ah) while empowering students with ethical behavior, community service, and essential modern literacy.",
    missionTitle: "Our Blessed Mission",
    missionText: "To impart traditional Islamic fields of science (Shari'ah, Tajweed, Fiqh, and Hadith) combined with high morals, ensuring our memorizers and scholars can lead the modern global Muslim community spiritually and intellectually.",
    visionTitle: "Our Divine Vision",
    visionText: "To become a pioneering center of academic and spiritual excellence that produces exemplary citizens who spread peace, universal Islamic brotherhood, and sound knowledge in line with Islamic traditions.",
    studentsCount: "350+",
    studentsLabel: "Enrolled Students",
    teachersCount: "18+",
    teachersLabel: "Qualified Ulema & Teachers",
    classesCount: "12+",
    classesLabel: "Active Classrooms & Halqas",
    establishedCount: "2004",
    establishedLabel: "Year Founded",
    coursesTitle: "Our Educational Curriculum",
    coursesSubtitle: "Nurturing intellectual depth, fluent recitation, and comprehensive spiritual knowledge.",
    facilitiesTitle: "Institution Facilities",
    facilitiesSubtitle: "Providing an environment of comfort and peace to empower students' dedicated learning path.",
    galleryTitle: "Glimpses of Darul Uloom",
    gallerySubtitle: "Visual journey through our campus, events, classrooms, and spiritual gatherings.",
    documentsTitle: "Documents Desk",
    documentsSubtitle: "Download official administrative documents, booklets, syllabus prospectus, and donation statements freely.",
    donationTitle: "Help Us Build the Future of Islam",
    donationSubtitle: "Support our construction projects, student meals, and educational needs through your direct contributions.",
    testimonialsTitle: "What Our Community Says",
    testimonialsSubtitle: "Reflections from community leaders, parents, and former graduates who walked our halls.",
    contactTitle: "Get in Touch",
    contactSubtitle: "Have questions about admissions, events, or donations? Contact our administrative desk today.",
    addressLabel: "Physical Location",
    phoneLabel: "Phone Number",
    emailLabel: "Email Address",
    whatsappLabel: "WhatsApp Direct",
    contactFormTitle: "Send a Message",
    contactNamePlaceholder: "Your Blessed Name...",
    contactEmailPlaceholder: "Your Active Email...",
    contactPhonePlaceholder: "Your Contact Number...",
    contactMsgPlaceholder: "Write your message or inquiry here...",
    contactSubmitBtn: "Send Message to Admin",
    footerTagline: "Sowing the seeds of Islamic spiritual wisdom and modern ethical excellence under the blessed spiritual guidance of the pious.",
    quickLinks: "Quick Sections",
    newsletterTitle: "Stay Tuned",
    newsletterBtn: "Subscribe"
  },
  ur: {
    schoolName: "دار العلوم رضاِ غوثِ اعظم",
    locationDetails: "تاج نگر، ہاویری، کرناٹک، انڈیا",
    navHome: "صفحہ اول",
    navAbout: "ہمارے بارے میں",
    navCourses: "شعبہ جاتِ تعلیم",
    navFacilities: "سہولیات",
    navGallery: "نگارخانہ (گیلری)",
    navDocuments: "دستاویزات و رپورٹس",
    navDonation: "عطیات و صدقات",
    navAnnouncements: "اعلانات و اطلاعات",
    navContact: "رابطہ کریں",
    regNumber: "رجسٹریشن نمبر: KAR/HVR/786/2004",
    callUs: "رابطہ کریں",
    whatsAppButton: "واٹس ایپ",
    admissionOpen: "داخلے جاری ہیں تعلیمی سال (۲۰۲۶-۲۰۲۷)",
    donateNow: "دل کھول کر عطیہ کریں (زکوٰۃ/صدقہ/خیرات)",
    prayerTimesTitle: "اوقاتِ نماز باجماعت",
    announcementsTitle: "اہم اعلانات اور خبریں",
    aboutTitle: "جامعہ کے بارے میں",
    aboutSubtitle: "اسلامی اقدار، مضبوط علمی تربیت اور صالح قیادت کی ایک معیاری درسگاہ۔",
    aboutHistoryTitle: "عقیدہ اور علم کی کثیر الجہتی خدمات",
    aboutHistoryText: "دار العلوم رضاِ غوثِ اعظم، تاج نگر، ہاویری علم کا ایک معتبر گہوارہ ہے، جس کا نام قطبِ ربانی، غوثِ اعظم شیخ عبد القادر جیلانی سے منسوب ہے۔ ہمارا مشن مسلکِ اہل سنت و جماعت پر قائم رہتے ہوئے قرآن و حدیث، فقہ و اصول کی تعلیم عام کرنا ہے، ساتھ ہی طلبہ کو جدید چیلنجز سے نبرد آزما ہونے کے لیے ضروری اخلاقی اور دنیاوی تعلیم فراہم کرنا بھی ہے۔",
    missionTitle: "ہمارا مقصد",
    missionText: "طلبہ کو روایتی اسلامی علوم (شریعت، تجوید، فقہ اور حدیث) میں پختہ کرنے کے ساتھ ساتھ اعلیٰ درجے کا پرہیزگار، دورِ جدید کے مسائل کا ادراک رکھنے والا بنانا تاکہ وہ ملتِ اسلامیہ کی صحیح رہنمائی کر سکیں۔",
    visionTitle: "ہمارا خواب",
    visionText: "ایک ایسی باوقار اور مربوط تعلیمی فضا قائم کرنا جہاں سے فارغ التحصیل علماء امن، بھائی چارہ، اور علمی روشنی پوری دنیا میں عام کریں۔",
    studentsCount: "+۳۵۰",
    studentsLabel: "زیرِ تعلیم طلبہ",
    teachersCount: "+۱۸",
    teachersLabel: "مستند اساتذہ و مفتیانِ کرام",
    classesCount: "+۱۲",
    classesLabel: "فعال کلاس رومز و حلقہ ہائے حفظ",
    establishedCount: "۲۰۰۴",
    establishedLabel: "سالِ قیام",
    coursesTitle: "ہمارے شعبہ جاتِ تعلیم",
    coursesSubtitle: "قرآن فہمی، تجوید، حفظ اور مضبوط معقول و منقول علوم کا جامع نصاب۔",
    facilitiesTitle: "جامعہ کی سہولیات",
    facilitiesSubtitle: "طلبہ کی تعلیم و تربیت کے لیے پرسکون اور روحانی فضا کی فراہمی۔",
    galleryTitle: "تصاریر و جھلکیاں",
    gallerySubtitle: "دار العلوم کے مناظر، تعلیمی حلقے، علمی محافل اور امتحانات کی بصری جھلکیاں۔",
    documentsTitle: "دفتری دستاویزات",
    documentsSubtitle: "جامعہ کا نصاب، سالانہ تعلیمی رپورٹ، رجسٹریشن سرٹیفکیٹ اور فنڈ تفصیلات ڈاؤن لوڈ کریں۔",
    donationTitle: "دینِ اسلام کی ترویج میں ہمارا ساتھ دیں",
    donationSubtitle: "طلبہ کی کفالت، غریب طلبہ کے طعام و قیام اور زیرِ تعمیر عمارت کے کاموں کے لیے اپنا حصہ ڈالیں۔",
    testimonialsTitle: "محبّانِ جامعہ کے تاثرات",
    testimonialsSubtitle: "سرپرستوں، معزز علماء، اور فارغ التحصیل فضلاء کے مخلصانہ تاثرات۔",
    contactTitle: "رابطہ اور معلومات",
    contactSubtitle: "داخلے یا عطیات کے متعلق کسی بھی قسم کے سوالات کے لیے انتظامیہ سے براہِ راست رابطہ قائم کریں۔",
    addressLabel: "پتہ دار العلوم",
    phoneLabel: "فون نمبر",
    emailLabel: "ای میل پتہ",
    whatsappLabel: "واٹس ایپ چیٹ",
    contactFormTitle: "ایک پیغام ارسال کریں",
    contactNamePlaceholder: "آپ کا اسمِ گرامی...",
    contactEmailPlaceholder: "آپ کا ای میل...",
    contactPhonePlaceholder: "آپ کا موبائل نمبر...",
    contactMsgPlaceholder: "اپنا پیغام یا سوال یہاں تحریر کریں...",
    contactSubmitBtn: "پیغام بھیجیں",
    footerTagline: "روحانیت اور علمی عظمت کے زیرِ سایہ نسلِ نو کی ترقی اور رہنمائی کا پرعزم مرکز۔",
    quickLinks: "فوری لنکس",
    newsletterTitle: "تازہ ترین خبریں پائیں",
    newsletterBtn: "سبسکرائب"
  }
};

export const courses: Course[] = [
  {
    id: "hifz",
    titleEn: "Hifz-ul-Quran",
    titleUr: "حفظ القرآن الكريم",
    arabicName: "حِفْظُ القُرْآنِ الكَرِيمِ مَعَ التَّجْوِيد",
    descEn: "Complete memorization of the Holy Quran under standard Arabic pronunciation (Tajweed-ul-Quran) and accent rules under leading specialized Huffaz.",
    descUr: "قرآن مجید کے حفظ کی تعلیم، تجوید کے سخت قواعد اور قراءتِ سبعہ کے ساتھ، تاکہ طلبہ درست تلفظ اور پختہ یادداشت کے ساتھ منزل مکمل کرسکیں۔",
    durationEn: "3 Years",
    durationUr: "۳ سال",
    icon: "BookOpen"
  },
  {
    id: "nazra",
    titleEn: "Nazra Quran",
    titleUr: "ناظرہ قرآن",
    arabicName: "نَاظِرَةُ القُرْآنِ الكَرِيم",
    descEn: "Elementary and progressive reading of the Noble Quran with perfect phonetic phonetics, basic Noorani Qaida, and daily Salah supplications.",
    descUr: "بچوں کو قرآن مجید دیکھ کر صحیح مخارج کے ساتھ پڑھنا سکھانا، جس میں نورانی قاعدہ اور روزمرہ کی مسنون دعائیں شامل ہیں۔",
    durationEn: "1 Year",
    durationUr: "۱ سال",
    icon: "HeartHandshake"
  },
  {
    id: "islamic_studies",
    titleEn: "Islamic Studies (Deeniyat)",
    titleUr: "اسلامیات و دینیات",
    arabicName: "شُعْبَةُ الدِّينِيَّاتِ العَامَّة",
    descEn: "Core concepts of faith (Aqeedah), purification (Taharah), jurisprudence (Fiqh) relative to daily worship, virtues, morals, and Sunnah biography.",
    descUr: "بنیادی عقائد، وضو، غسل، فرائض، اور روزمرہ کی زندگی کے ضروری مسائل کی تعلیم، سیرتِ طیبہ اور اخلاقیات کی بنیادی تربیت۔",
    durationEn: "2 Years",
    durationUr: "۲ سال",
    icon: "Compass"
  },
  {
    id: "arabic_language",
    titleEn: "Arabic Language & Grammar",
    titleUr: "عربی زبان و قواعد",
    arabicName: "اللُّغَةُ العَرَبِيَّةُ وَالنَّحْوُ وَالصَّرْف",
    descEn: "Mastering classical Arabic, morphology (Sarf), syntax (Nahw), text comprehension, translation, and fluent written and spoken communication.",
    descUr: "قرآن و کتبِ احادیث کو سمجھنے کے لیے عربی گرامر (صرف و نحو)، بلاغت، اور عربی تکلم و تحریر میں مہارت حاصل کرنا۔",
    durationEn: "2 Years",
    durationUr: "۲ سال",
    icon: "Languages"
  },
  {
    id: "urdu_education",
    titleEn: "Urdu Education & Literature",
    titleUr: "اردو تعلیم و ادب",
    arabicName: "الدِّرَاسَاتُ الأُرْدِيَّةُ وَالأَدَب",
    descEn: "Extensively covering Urdu language modules, writing style development, historical literature, poetry, and sermon delivery techniques (Khutbah).",
    descUr: "اردو زبان کی ترویج، خوش خطی، خطاطی، مروج اردو ادب، اور تقاریر و خطابت (خطبہ جمعہ و عیدین) کا کامیاب نظام۔",
    durationEn: "1 Year",
    durationUr: "۱ سال",
    icon: "PenTool"
  },
  {
    id: "dars_enizami",
    titleEn: "Dars-e-Nizami (Alim Course)",
    titleUr: "درسِ نظامی (عالم کورس)",
    arabicName: "عَالِمِيَّة - الدَّرْسُ النِّظَامِي",
    descEn: "Master-level intensive theological training spanning logical science, Usul-ul-Hadith, Tafseer-ul-Baydawi, advanced Hanafi Islamic law, and heritage.",
    descUr: "ایک مکمل اسلامی علم حاصل کرنے کا نصاب (عالمیت) جس میں تفسیر، اصولِ تفسیر، تجرید البخاری، ہدایہ (فقہ)، اصولِ فقہ، منطق اور اسلامی تاریخ پڑھائی جاتی ہے۔",
    durationEn: "6 Years",
    durationUr: "۶ سال",
    icon: "GraduationCap"
  }
];

export const facilities: Facility[] = [
  {
    id: "teachers",
    titleEn: "Qualified Teachers",
    titleUr: "باصلاحیت و مخلص اساتذہ",
    descEn: "Our faculty database comprises authorized scholars from leading Islamic universities, carrying certified dynamic chains of knowledge transmission.",
    descUr: "ہمارے اساتذہ مستند مدارس اور معتبر جامعات کے فارغ التحصیل ہیں جن کے پاس علم و تربیت کا مستند تجربہ اور سند موجود ہے۔",
    icon: "Award"
  },
  {
    id: "library",
    titleEn: "Islamic Library",
    titleUr: "اسلامی لائبریری (کتب خانہ)",
    descEn: "Stocked with thousands of traditional research reference guides, historic commentaries, dictionaries, contemporary booklets, and textbooks.",
    descUr: "ہزاروں مستند کتابوں، فقہی تفاسیر، تاریخ کی اہم ترین کتب اور جدید دور کے موضوعات پر مشتمل کتب کا ایک وسیع ذخیرہ۔",
    icon: "BookOpenCheck"
  },
  {
    id: "hostel",
    titleEn: "Hostel Facility",
    titleUr: "دارالاقامہ (ہاسٹل کی سہولت)",
    descEn: "Free boarding, comfortable dormitory facilities, strict surveillance, and high nutritional standard meals for long-distance students.",
    descUr: "دور دراز کے طلبہ کے لیے پرسکون کمرے، صفائی ستھرائی کا نظام، اور روزانہ معیاری و صحت بخش لذیذ طعام و قیام کا مفت انتظام۔",
    icon: "Home"
  },
  {
    id: "prayer_hall",
    titleEn: "Spacious Prayer Hall",
    titleUr: "وسیع مسجد و ہال",
    descEn: "A magnificent and serene prayer atmosphere featuring daily five-time prayers, localized spiritual gatherings, and special Ramadan Nawafil.",
    descUr: "روحانیت اور سکون سے لبریز ایک وسیع مسجد، جہاں باقاعدگی کے ساتھ پانچوں وقت کی نماز باجماعت اور محافل کا انعقاد ہوتا ہے۔",
    icon: "Milestone"
  },
  {
    id: "clean_env",
    titleEn: "Hygiene & Cleanliness",
    titleUr: "پاکیزہ اور صاف ستھرا ماحول",
    descEn: "Excellent architectural layout conforming to rigorous health standards, clean drinking water, and lush physical play surroundings.",
    descUr: "طہارت نصف ایمان ہے، کے اصول پر عمل کرتے ہوئے دار العلوم میں بہترین صفائی ستھرائی، پینے کے صاف پانی اور کھلی اور ہوا دار عمارت کا انتظام۔",
    icon: "Sparkles"
  },
  {
    id: "support",
    titleEn: "Comprehensive Support",
    titleUr: "طلبہ کی مکمل سرپرستی",
    descEn: "Providing free clothing, text syllabus materials, continuous health medication checkups, and travel guidance for orphaned and underprivileged kids.",
    descUr: "مستحق اور یتیم طلبہ کو مفت نصابی کتب، ادویات، سالانہ لباس اور سفری سہولیات سمیت ہر ممکنہ مالی و اخلاقی امداد۔",
    icon: "Heart"
  }
];

export const documents: DocumentItem[] = [
  {
    id: "doc_prospectus",
    titleEn: "Syllabus Prospectus & Admission Guide 2026",
    titleUr: "نصاب و معلوماتِ داخلہ بروشر ۲۰۲۶",
    fileSize: "2.4 MB PDF",
    dateStrEn: "June 2026",
    dateStrUr: "جون ۲۰۲۶"
  },
  {
    id: "doc_annual_report",
    titleEn: "Annual Educational Progress Survey Report",
    titleUr: "سرگذشت و سالانہ تعلیمی رپورٹ",
    fileSize: "4.1 MB PDF",
    dateStrEn: "April 2026",
    dateStrUr: "اپریل ۲۰۲۶"
  },
  {
    id: "doc_certificate",
    titleEn: "Government Registration Certificate (Copy)",
    titleUr: "رجسٹریشن سرٹیفکیٹ کی نقل",
    fileSize: "1.2 MB PDF",
    dateStrEn: "Registered Jan 2004",
    dateStrUr: "جنوری ۲۰۰۴"
  },
  {
    id: "doc_donation_audit",
    titleEn: "Donation Audit & Expenses Statement",
    titleUr: "آمد و خرچ اور حسابات کی آڈٹ رپورٹ",
    fileSize: "3.5 MB PDF",
    dateStrEn: "May 2026",
    dateStrUr: "مئی ۲۰۲۶"
  }
];

export const testimonials: Testimonial[] = [
  {
    id: "t1",
    authorEn: "Mufti Muhammad Ibrahim Qadiri",
    authorUr: "مفتی محمد ابراہیم قادری",
    roleEn: "Founder Sheikh of Haveri Shari'ah Board",
    roleUr: "بانی و سرپرست، ہاویری شرعی بورڈ",
    quoteEn: "Darul Uloom Raza-E-Gous-E-Azam is carrying out unprecedented services of educating Islamic ethics. Their students display remarkable character and profound reverence of classical Islamic scholars.",
    quoteUr: "دار العلوم رضاِ غوثِ اعظم نے ہاویری اور اس کے گرد و نواح میں علم و عمل کی جو شمع جلائی ہے، وہ قابلِ صد ستائش ہے۔ یہاں کے بچوں کی طہارت، قرأت اور اسلامی تہذیب دیکھ کر دل باغ باغ ہوجاتا ہے۔"
  },
  {
    id: "t2",
    authorEn: "Alhaj Dr. Shafiullah Khan",
    authorUr: "الحاج ڈاکٹر شفیع اللہ خان",
    roleEn: "Local Community Patron & Parent",
    roleUr: "سرپرست اور سماجی کارکن",
    quoteEn: "My young child memorized the entire Quran here within 2.5 years. The love, affection, and personal health oversight provided by Hazrat Maulana and the teacher's team is truly stellar and rare.",
    quoteUr: "میرے بیٹے نے اسی دار العلوم میں اڑھائی سال کی قلیل مدت میں قرآن حفظ مکمل کیا۔ اساتذہ کا پیار و شفقت بالخصوص حفظ کا ماحول اور نگرانی غیر معمولی ہے۔ یہ ہمارے علاقے کا عظیم تعلیمی سرمایہ ہے۔"
  },
  {
    id: "t3",
    authorEn: "Maulana Ashfaq Alam Misbahi",
    authorUr: "مولانا اشفاق عالم مصباحی",
    roleEn: "Academic Inspector of Deeni Madaris, Karnataka",
    roleUr: "ناظمِ امتحانات و معائنہ کار، مدارسِ اسلامیہ",
    quoteEn: "The educational system of this Madrasa correctly balances conventional Arabic syntax with essential modern requirements. Their examinations are standardized, fair, and exceptionally planned.",
    quoteUr: "میں نے اس جامعہ کے سالانہ تعلیمی جانچ کا بذاتِ خود مشاہدہ کیا۔ یہ معقول اور منقول دونوں نظاموں کا ایک بہترین اور منظم امتزاج ہے، جو طلبہ کی حقیقی فلاح میں معاون ثابت ہوتا ہے۔"
  }
];

export const announcements: Announcement[] = [
  {
    id: "ann_1",
    textEn: "🌙 Alhumdulillah! Admissions are now completely OPEN for Hifz, Nazra, and Alim Course courses (Academic Year 2026-2027). Hostels can accommodate fresh candidates immediately. Contact the principal's office today.",
    textUr: "🌙 الحمد للہ! سالِ نو تعلیمی سالِ ۲۰۲۶-۲۰۲۷ کے لیے داخلے جاری ہیں۔ ناظرہ، مفتیان، عالمیت اور حفظ کے نئے طلبہ فوری ہاسٹل میں تشریف لاسکتے ہیں۔ رجسٹریشن کے لیے دفتری اوقات میں رابطہ کریں۔",
    isImportant: true,
    date: "2026-06-01"
  },
  {
    id: "ann_2",
    textEn: "🕌 Notice: Completion of the beautiful first-floor slab of the new girls' block and mosque wing. We appeals to all patrons to continue their construction donations so that paint and tile work finishes soon.",
    textUr: "🕌 اہم اپیل: نئی عمارت (طالبات بلاک اور بیرونی وضو خانے) کے پہلے مرحلے کا کام مکمل۔ فرش اور ٹائلز کا کام جلد پورا کروانے کے لیے مخلصینِ ملت اپنے عطیات و صدقات جاری رکھیں۔",
    isImportant: false,
    date: "2026-05-28"
  },
  {
    id: "ann_3",
    textEn: "📜 Announcement: Annual Grand Spiritual Jalsa and Dastar-e-Fazeelat is scheduled. Multiple honorable scholars from Bareilly Shareef, Mumbai, and Hubballi will address the dynamic gathering. Keep prayers in sight.",
    textUr: "📜 بشارت: تاریخی عظیم الشان سالانہ جلسہ عام دستارِ فضیلت و تقسیمِ اسناد کی تاریخِ حتمی کا اعلان جلد ہوگا۔ مقتدر علماء کرام و مشائخِ عظام ہند تشریف لا رہے ہیں۔ دعا و شرکت کے لیے تیاری فرمائیں۔",
    isImportant: true,
    date: "2026-05-20"
  }
];

// Curated high quality educational & Islamic illustrations
export const galleryItems: GalleryItem[] = [
  {
    id: "g1",
    titleEn: "Sacred Quran Recitation Halqa",
    titleUr: "دار العلوم کے ننھے طلبہ حفظِ قرآن کی مجلس میں",
    categoryEn: "Classes",
    categoryUr: "شعبہ جات",
    image: "https://images.unsplash.com/photo-1542810634-71277d95dcbb?auto=format&fit=crop&q=80&w=1200"
  },
  {
    id: "g2",
    titleEn: "Main Entrance & Library Portal",
    titleUr: "اسلامی تحقیق کرنے والے باصلاحیت طلباء",
    categoryEn: "Campus",
    categoryUr: "کیمپس",
    image: "https://images.unsplash.com/photo-1576092768241-dec231879fc3?auto=format&fit=crop&q=80&w=1200"
  },
  {
    id: "g3",
    titleEn: "Under Construction Girls Section Building",
    titleUr: "زیرِ تعمیر دار العلوم کا نیا تعلیمی ہال",
    categoryEn: "Events",
    categoryUr: "تقاریب و تعمیرات",
    image: "https://images.unsplash.com/photo-1507679799987-c73779587ccf?auto=format&fit=crop&q=80&w=1200"
  },
  {
    id: "g4",
    titleEn: "Scholars Assembling at Annual Event",
    titleUr: "سالانہ جلسے میں مہمان علماء و شیوخِ عظام کا خطاب",
    categoryEn: "Events",
    categoryUr: "تقاریب و تعمیرات",
    image: "https://images.unsplash.com/photo-1585829365295-ab7cd400c167?auto=format&fit=crop&q=80&w=1200"
  },
  {
    id: "g5",
    titleEn: "Evening Quran Lessons (Gousia Block)",
    titleUr: "غروبِ آفتاب کے وقت تجوید کی تدریس",
    categoryEn: "Classes",
    categoryUr: "شعبہ جات",
    image: "https://images.unsplash.com/photo-1519751138087-5bf79df62d5b?auto=format&fit=crop&q=80&w=1200"
  },
  {
    id: "g6",
    titleEn: "Academic Study Material Distribution",
    titleUr: "ضروری نصابی کتب اور انعامات کی تقسیمِ اسناد",
    categoryEn: "Campus",
    categoryUr: "کیمپس",
    image: "https://images.unsplash.com/photo-1506784983877-45594efa4cbe?auto=format&fit=crop&q=80&w=1200"
  }
];

export const defaultPrayerTimes: PrayerTime[] = [
  { name: "Fajr", nameUr: "فجر", arabic: "الفجر", time: "04:45 AM" },
  { name: "Zuhr", nameUr: "ظہر", arabic: "الظهر", time: "01:30 PM" },
  { name: "Asr", nameUr: "عصر", arabic: "العصر", time: "05:15 PM" },
  { name: "Maghrib", nameUr: "مغرب", arabic: "المغرب", time: "06:55 PM" },
  { name: "Isha", nameUr: "عشاء", arabic: "العشاء", time: "08:35 PM" },
  { name: "Friday Prayer", nameUr: "نمازِ جمعہ", arabic: "الجمعة", time: "01:30 PM" }
];
