export type Language = 'en' | 'ur';

export interface TranslationDict {
  navHome: string;
  navAbout: string;
  navCourses: string;
  navFacilities: string;
  navGallery: string;
  navDocuments: string;
  navDonation: string;
  navAnnouncements: string;
  navContact: string;
  regNumber: string;
  callUs: string;
  whatsAppButton: string;
  admissionOpen: string;
  donateNow: string;
  prayerTimesTitle: string;
  announcementsTitle: string;
  aboutTitle: string;
  aboutSubtitle: string;
  aboutHistoryTitle: string;
  aboutHistoryText: string;
  missionTitle: string;
  missionText: string;
  visionTitle: string;
  visionText: string;
  studentsCount: string;
  teachersCount: string;
  classesCount: string;
  establishedCount: string;
  studentsLabel: string;
  teachersLabel: string;
  classesLabel: string;
  establishedLabel: string;
  coursesTitle: string;
  coursesSubtitle: string;
  facilitiesTitle: string;
  facilitiesSubtitle: string;
  galleryTitle: string;
  gallerySubtitle: string;
  documentsTitle: string;
  documentsSubtitle: string;
  donationTitle: string;
  donationSubtitle: string;
  testimonialsTitle: string;
  testimonialsSubtitle: string;
  contactTitle: string;
  contactSubtitle: string;
  addressLabel: string;
  phoneLabel: string;
  emailLabel: string;
  whatsappLabel: string;
  contactFormTitle: string;
  contactNamePlaceholder: string;
  contactEmailPlaceholder: string;
  contactPhonePlaceholder: string;
  contactMsgPlaceholder: string;
  contactSubmitBtn: string;
  footerTagline: string;
  quickLinks: string;
  newsletterTitle: string;
  newsletterBtn: string;
  schoolName: string;
  locationDetails: string;
}

export interface Course {
  id: string;
  titleEn: string;
  titleUr: string;
  arabicName: string;
  descEn: string;
  descUr: string;
  durationEn: string;
  durationUr: string;
  icon: string;
}

export interface Facility {
  id: string;
  titleEn: string;
  titleUr: string;
  descEn: string;
  descUr: string;
  icon: string;
}

export interface DocumentItem {
  id: string;
  titleEn: string;
  titleUr: string;
  fileSize: string;
  dateStrEn: string;
  dateStrUr: string;
}

export interface Testimonial {
  id: string;
  authorEn: string;
  authorUr: string;
  roleEn: string;
  roleUr: string;
  quoteEn: string;
  quoteUr: string;
}

export interface GalleryItem {
  id: string;
  titleEn: string;
  titleUr: string;
  categoryEn: string;
  categoryUr: string;
  image: string;
}

export interface Announcement {
  id: string;
  textEn: string;
  textUr: string;
  isImportant: boolean;
  date: string;
}

export interface PrayerTime {
  name: string;
  nameUr: string;
  arabic: string;
  time: string;
}
