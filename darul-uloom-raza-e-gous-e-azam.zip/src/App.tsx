/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  BookOpen,
  HeartHandshake,
  Compass,
  Languages,
  PenTool,
  GraduationCap,
  Award,
  BookOpenCheck,
  Home,
  Milestone,
  Sparkles,
  Heart,
  Calendar,
  Clock,
  Phone,
  Mail,
  MapPin,
  Menu,
  X,
  ChevronUp,
  Download,
  ExternalLink,
  Sun,
  Moon,
  QrCode,
  Share2,
  CheckCircle,
  Copy,
  TrendingUp,
  Check,
  MessageSquare,
  ArrowRight,
  ArrowLeft,
  Info,
  History as HistoryIcon
} from 'lucide-react';
import { translations, courses, facilities, documents, testimonials, announcements, galleryItems, defaultPrayerTimes } from './data';
import { Language, Course, Facility, DocumentItem, Testimonial, GalleryItem, Announcement, PrayerTime } from './types';

// Dynamic mapping of lucide components for courses and facilities
const IconMap: Record<string, React.ComponentType<any>> = {
  BookOpen,
  HeartHandshake,
  Compass,
  Languages,
  PenTool,
  GraduationCap,
  Award,
  BookOpenCheck,
  Home,
  Milestone,
  Sparkles,
  Heart
};

export default function App() {
  // State management
  const [lang, setLang] = useState<Language>('ur'); // Defaulting to Urdu as a professional gesture, user can switch easily
  const [darkMode, setDarkMode] = useState<boolean>(true); // Elegant dark mode default looks highly premium with Islamic gold/emerald theme
  const [menuOpen, setMenuOpen] = useState<boolean>(false);
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);
  const [copiedField, setCopiedField] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<string>('all');
  
  // Custom interactive simulations
  const [showToast, setShowToast] = useState<{ message: string; visible: boolean }>({ message: '', visible: false });
  const [downloadingId, setDownloadingId] = useState<string | null>(null);
  const [downloadProgress, setDownloadProgress] = useState<number>(0);
  const [formSubmitted, setFormSubmitted] = useState<boolean>(false);
  const [contactForm, setContactForm] = useState({ name: '', email: '', phone: '', message: '' });
  const [mapType, setMapType] = useState<'roadmap' | 'satellite'>('roadmap');
  
  // Current time state for the interactive clock and prayer timing countdown
  const [currentTime, setCurrentTime] = useState<Date>(new Date());
  const [showScrollTop, setShowScrollTop] = useState<boolean>(false);

  // Load configuration from local preferences if exists
  useEffect(() => {
    const savedLang = localStorage.getItem('darululoom_lang') as Language;
    if (savedLang) setLang(savedLang);
    
    const savedTheme = localStorage.getItem('darululoom_theme');
    if (savedTheme) {
      setDarkMode(savedTheme === 'dark');
    }
  }, []);

  // Set html context direction and font styles when language changes
  useEffect(() => {
    localStorage.setItem('darululoom_lang', lang);
    document.documentElement.dir = lang === 'ur' ? 'rtl' : 'ltr';
    document.documentElement.lang = lang;
  }, [lang]);

  // Keep dark class in sync
  useEffect(() => {
    localStorage.setItem('darululoom_theme', darkMode ? 'dark' : 'light');
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  // Handle ticking clock and monitor interactive animations
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Monitor screen scroll to toggle visibility of scroll to top button
  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 400) {
        setShowScrollTop(true);
      } else {
        setShowScrollTop(false);
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const t = translations[lang];

  // Helper code to format standard dynamic date/clock displays
  const formatTimeStr = (date: Date) => {
    return date.toLocaleTimeString(lang === 'ur' ? 'ur-PK' : 'en-US', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: true
    });
  };

  const formatDateStr = (date: Date) => {
    const options: Intl.DateTimeFormatOptions = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
    return date.toLocaleDateString(lang === 'ur' ? 'ur-PK' : 'en-US', options);
  };

  // Helper to copy text with an instant toast success feedback
  const triggerCopy = (text: string, identifier: string) => {
    navigator.clipboard.writeText(text);
    setCopiedField(identifier);
    triggerToast(lang === 'ur' ? 'معلومات کاپی ہوگئی ہیں!' : 'Information copied successfully!');
    setTimeout(() => {
      setCopiedField(null);
    }, 2500);
  };

  const triggerToast = (msg: string) => {
    setShowToast({ message: msg, visible: true });
    setTimeout(() => {
      setShowToast(prev => ({ ...prev, visible: false }));
    }, 3500);
  };

  // Helper to simulate prospectus and annual report PDF downloads with percentage status
  const startSimulationDownload = (doc: DocumentItem) => {
    if (downloadingId) return; // Prevent concurrent downloads animation
    setDownloadingId(doc.id);
    setDownloadProgress(0);
    
    triggerToast(lang === 'ur' ? `${doc.titleUr} ڈاؤن لوڈ ہورہا ہے...` : `Simulating download for ${doc.titleEn}...`);

    const interval = setInterval(() => {
      setDownloadProgress(p => {
        if (p >= 100) {
          clearInterval(interval);
          setTimeout(() => {
            setDownloadingId(null);
            triggerToast(lang === 'ur' ? `${doc.titleUr} کامیابی سے ڈاؤن لوڈ ہوگیا!` : `${doc.titleEn} downloaded successfully!`);
          }, 400);
          return 100;
        }
        return p + 20;
      });
    }, 250);
  };

  // Handle contact form simulation
  const handleContactSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!contactForm.name || !contactForm.phone) {
      triggerToast(lang === 'ur' ? 'براہِ کرم نام اور موبائل نمبر درج کریں۔' : 'Please input your name and phone number.');
      return;
    }
    setFormSubmitted(true);
    triggerToast(lang === 'ur' ? 'آپ کا پیغام ایڈمن کو بھیج دیا گیا ہے، ہم جلد رابطہ کریں گے۔' : 'Message dispatched to Darul Uloom administrator successfully!');
    setContactForm({ name: '', email: '', phone: '', message: '' });
    setTimeout(() => setFormSubmitted(false), 5000);
  };

  // Helper to detect current/upcoming congregational prayer
  // Parses a string like "04:45 AM" into minutes of the day to identify what's next
  const getNextPrayer = (): { name: string; nameUr: string; time: string; minutesLeft: number } => {
    const hours = currentTime.getHours();
    const minutes = currentTime.getMinutes();
    const currentAbsMinutes = hours * 60 + minutes;

    let closestTimeDiff = Infinity;
    let nextPrayerIdx = 0;

    const parsedTimes = defaultPrayerTimes.map(p => {
      let [timeParts, modifier] = p.time.split(' ');
      let [hStr, mStr] = timeParts.split(':');
      let h = parseInt(hStr);
      let m = parseInt(mStr);
      if (modifier === 'PM' && h !== 12) h += 12;
      if (modifier === 'AM' && h === 12) h = 0;
      let absMinutes = h * 60 + m;
      return { ...p, absMinutes };
    });

    for (let i = 0; i < parsedTimes.length; i++) {
      let diff = parsedTimes[i].absMinutes - currentAbsMinutes;
      // If the prayer time has already passed today, it will occur tomorrow (add 24 hours)
      if (diff <= 0) {
        diff += 24 * 60;
      }
      if (diff < closestTimeDiff) {
        closestTimeDiff = diff;
        nextPrayerIdx = i;
      }
    }

    const target = parsedTimes[nextPrayerIdx];
    return {
      name: target.name,
      nameUr: target.nameUr,
      time: target.time,
      minutesLeft: closestTimeDiff
    };
  };

  const nextPrayer = getNextPrayer();

  // Scroll smoothly to any specific DOM element
  const scrollToSection = (id: string) => {
    setMenuOpen(false);
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  // Gallery items filtering logic
  const filteredGallery = selectedCategory === 'All'
    ? galleryItems
    : galleryItems.filter(item => item.categoryEn === selectedCategory);

  const prevGalleryItem = () => {
    if (lightboxIndex === null) return;
    setLightboxIndex(prev => (prev !== null && prev > 0 ? prev - 1 : filteredGallery.length - 1));
  };

  const nextGalleryItem = () => {
    if (lightboxIndex === null) return;
    setLightboxIndex(prev => (prev !== null && prev < filteredGallery.length - 1 ? prev + 1 : 0));
  };

  return (
    <div className={`min-h-screen text-slate-800 transition-colors duration-300 islamic-pattern ${darkMode ? 'dark bg-slate-950 text-slate-100 islamic-pattern-dark' : 'bg-slate-50'}`}>
      
      {/* Dynamic Toast System */}
      <AnimatePresence>
        {showToast.visible && (
          <motion.div
            initial={{ opacity: 0, y: 50, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            className="fixed bottom-6 right-6 left-6 md:left-auto md:max-w-md z-50 glass-emerald border-l-4 border-emerald-500 rounded-xl shadow-2xl p-4 flex items-center justify-between gap-3 text-emerald-950 dark:text-emerald-100 bg-white/95 dark:bg-slate-900/95"
            dir={lang === 'ur' ? 'rtl' : 'ltr'}
          >
            <div className="flex items-center gap-3">
              <CheckCircle className="w-6 h-6 text-emerald-600 flex-shrink-0" />
              <p className={`text-sm ${lang === 'ur' ? 'font-urdu leading-loose' : 'font-sans'}`}>{showToast.message}</p>
            </div>
            <button onClick={() => setShowToast(prev => ({ ...prev, visible: false }))} className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200">
              <X className="w-5 h-5" />
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Top Banner & Quick Contacts */}
      <div className="bg-emerald-950 text-emerald-100/90 text-xs py-2 px-4 border-b border-amber-500/20">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-2">
          {/* Registration Number display as requested */}
          <div className="flex items-center gap-2">
            <span className="bg-amber-500/20 text-amber-300 font-semibold px-2.5 py-0.5 rounded-full text-[10px] tracking-wide uppercase border border-amber-500/30">
              {t.regNumber}
            </span>
          </div>

          {/* Core dynamic clock and active greeting */}
          <div className="flex items-center gap-6 text-[11px] md:text-xs">
            <span className="flex items-center gap-1.5 font-mono">
              <Clock className="w-3.5 h-3.5 text-amber-400" />
              {formatTimeStr(currentTime)}
            </span>
            <span className="hidden sm:inline-flex items-center gap-1.5">
              <Calendar className="w-3.5 h-3.5 text-amber-400" />
              {formatDateStr(currentTime)}
            </span>
            
            {/* Quick action buttons next to the countdown */}
            <div className="flex gap-2.5">
              <a href="tel:+919450884954" className="hover:text-amber-400 flex items-center gap-1 font-sans transition">
                <Phone className="w-3 h-3" />
                <span>+91 94508 84954</span>
              </a>
            </div>
          </div>
        </div>
      </div>

      {/* Sticky Premium Navigation Header */}
      <header className="sticky top-0 z-40 bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 shadow-sm transition-colors duration-300">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3 flex items-center justify-between">
          
          {/* Islamic Emblem Logo & Title Block */}
          <div className="flex items-center gap-3 cursor-pointer" onClick={() => scrollToSection('hero')}>
            {/* Sacred Custom SVG Emblem, styled with majestic gold and deep emerald */}
            <div className="w-12 h-12 rounded-full bg-gradient-to-tr from-emerald-800 to-emerald-600 flex items-center justify-center border-2 border-amber-400 shadow-md transform hover:scale-105 transition-transform duration-300">
              <svg viewBox="0 0 100 100" className="w-8 h-8 text-amber-300 fill-current">
                {/* Traditional Crescent and Mosque Dome silhouette vector */}
                <path d="M50 15c-19.3 0-35 15.7-35 35s15.7 35 35 35c8.9 0 17-3.3 23.2-8.8-16.7 1-31.2-11.4-31.2-28.2 0-15.1 11.8-26.4 26.8-26.8C62.8 17.5 56.6 15 50 15zm0 15c2.2 0 4 1.8 4 4v5c0 2.2-1.8 4-4 4s-4-1.8-4-4v-5c0-2.2 1.8-4 4-4zm-14 16c2.2 0 4 1.8 4 4v10c0 2.2-1.8 4-4 4s-4-1.8-4-4V39c0-2.2 1.8-4 4-4zm28 0c2.2 0 4 1.8 4 4v10c0 2.2-1.8 4-4 4s-4-1.8-4-4V39c0-2.2 1.8-4 4-4z" />
                {/* Spiritual Star / Noor motif */}
                <polygon points="50,5 53,12 60,12 55,16 57,23 50,19 43,23 45,16 40,12 47,12" className="animate-pulse" />
              </svg>
            </div>
            
            <div>
              <h1 className={`font-extrabold text-emerald-800 dark:text-emerald-400 leading-tight ${lang === 'ur' ? 'font-urdu text-lg md:text-xl' : 'font-sans tracking-tight text-sm md:text-base'}`}>
                {t.schoolName}
              </h1>
              <p className="text-[10px] text-slate-500 dark:text-slate-400 tracking-wider">
                {lang === 'ur' ? 'تاج نگر، ہاویری، کرناٹک' : 'TAJ NAGAR, HAVERI, KARNATAKA'}
              </p>
            </div>
          </div>

          {/* Desktop Navigation Links */}
          <nav className="hidden lg:flex items-center gap-6">
            <button onClick={() => scrollToSection('about')} className="text-sm font-medium hover:text-emerald-700 dark:hover:text-emerald-400 cursor-pointer transition">{t.navAbout}</button>
            <button onClick={() => scrollToSection('courses')} className="text-sm font-medium hover:text-emerald-700 dark:hover:text-emerald-400 cursor-pointer transition">{t.navCourses}</button>
            <button onClick={() => scrollToSection('facilities')} className="text-sm font-medium hover:text-emerald-700 dark:hover:text-emerald-400 cursor-pointer transition">{t.navFacilities}</button>
            <button onClick={() => scrollToSection('gallery')} className="text-sm font-medium hover:text-emerald-700 dark:hover:text-emerald-400 cursor-pointer transition">{t.navGallery}</button>
            <button onClick={() => scrollToSection('documents')} className="text-sm font-medium hover:text-emerald-700 dark:hover:text-emerald-400 cursor-pointer transition">{t.navDocuments}</button>
            <button onClick={() => scrollToSection('donation')} className="text-sm font-medium hover:text-emerald-700 dark:hover:text-emerald-400 cursor-pointer transition text-amber-600 dark:text-amber-400 font-semibold">{t.navDonation}</button>
            <button onClick={() => scrollToSection('contact')} className="text-sm font-medium hover:text-emerald-700 dark:hover:text-emerald-400 cursor-pointer transition">{t.navContact}</button>
          </nav>

          {/* Global Utility Controllers (Language, Theme, Buttons) */}
          <div className="flex items-center gap-2 sm:gap-3">
            
            {/* Dynamic Bilingual Language Toggle (RTL/LTR shift) */}
            <button
              onClick={() => setLang(l => l === 'en' ? 'ur' : 'en')}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-emerald-600/30 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-300 hover:bg-emerald-100 dark:hover:bg-emerald-900/50 transition-all font-semibold text-xs cursor-pointer shadow-sm"
              title="Toggle Language / زبان تبدیل کریں"
            >
              <Languages className="w-3.5 h-3.5" />
              <span>{lang === 'en' ? 'اردو' : 'English'}</span>
            </button>

            {/* Premium Dark Theme Switcher */}
            <button
              onClick={() => setDarkMode(!darkMode)}
              className="p-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/80 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 transition cursor-pointer"
              aria-label="Toggle Theme Mode"
            >
              {darkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-indigo-900" />}
            </button>

            {/* Quick Direct Support CTAs */}
            <a
              href="https://wa.me/919450884954?text=Peace%20be%20upon%20you.%20I%20am%20inquiring%20about%20Darul%20Uloom%20Raza-E-Gous-E-Azam"
              target="_blank"
              rel="noopener noreferrer"
              className="hidden sm:inline-flex items-center gap-1.5 bg-[#25D366] text-white hover:bg-[#1ebd5d] px-3.5 py-1.5 rounded-lg font-medium text-xs shadow-md transition transform active:scale-95"
            >
              <span className="w-2 h-2 rounded-full bg-white animate-ping"></span>
              {t.whatsAppButton}
            </a>

            {/* Mobile Navigation Trigger Overlay Button */}
            <button
              onClick={() => setMenuOpen(!menuOpen)}
              className="p-2 lg:hidden rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300 cursor-pointer"
              aria-label="Toggle Navigation menu"
            >
              {menuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation Drawer */}
        <AnimatePresence>
          {menuOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="lg:hidden bg-slate-50 dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 overflow-hidden"
            >
              <div className="px-4 py-4 space-y-2.5 flex flex-col items-stretch">
                <button onClick={() => { scrollToSection('about'); }} className="text-right py-2 px-3 hover:bg-emerald-50 dark:hover:bg-emerald-950/20 rounded-md transition font-medium text-sm">{t.navAbout}</button>
                <button onClick={() => { scrollToSection('courses'); }} className="text-right py-2 px-3 hover:bg-emerald-50 dark:hover:bg-emerald-950/20 rounded-md transition font-medium text-sm">{t.navCourses}</button>
                <button onClick={() => { scrollToSection('facilities'); }} className="text-right py-2 px-3 hover:bg-emerald-50 dark:hover:bg-emerald-950/20 rounded-md transition font-medium text-sm">{t.navFacilities}</button>
                <button onClick={() => { scrollToSection('gallery'); }} className="text-right py-2 px-3 hover:bg-emerald-50 dark:hover:bg-emerald-950/20 rounded-md transition font-medium text-sm">{t.navGallery}</button>
                <button onClick={() => { scrollToSection('documents'); }} className="text-right py-2 px-3 hover:bg-emerald-50 dark:hover:bg-emerald-950/20 rounded-md transition font-medium text-sm">{t.navDocuments}</button>
                <button onClick={() => { scrollToSection('donation'); }} className="text-right py-2 px-3 hover:bg-amber-50 dark:hover:bg-amber-950/20 text-amber-600 dark:text-amber-400 rounded-md transition font-semibold text-sm">{t.navDonation}</button>
                <button onClick={() => { scrollToSection('contact'); }} className="text-right py-2 px-3 hover:bg-emerald-50 dark:hover:bg-emerald-950/20 rounded-md transition font-medium text-sm">{t.navContact}</button>
                
                <div className="pt-3 border-t border-slate-200 dark:border-slate-800 flex flex-col gap-2">
                  <a
                    href="https://wa.me/919450884954"
                    target="_blank"
                    className="flex justify-center items-center gap-2 bg-[#25D366] text-white py-2 rounded-lg text-xs font-semibold"
                  >
                    <span>{t.whatsAppButton}</span>
                  </a>
                  <a
                    href="tel:+919450884954"
                    className="flex justify-center items-center gap-2 bg-emerald-600 text-white py-2 rounded-lg text-xs font-semibold"
                  >
                    <Phone className="w-3.5 h-3.5" />
                    <span>+91 94508 84954</span>
                  </a>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </header>

      {/* Scrolling Announcements Notice Ticker */}
      <section className="bg-amber-50 dark:bg-amber-950/20 border-b border-amber-500/10 py-2.5 overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 flex items-center gap-3">
          <div className="bg-amber-500 text-amber-950 px-3 py-1 rounded font-bold text-[11px] sm:text-xs uppercase flex-shrink-0 flex items-center gap-1.5 animate-pulse shadow-sm">
            <span className="w-1.5 h-1.5 rounded-full bg-white"></span>
            {lang === 'ur' ? 'اہم اعلانات:' : 'Updates:'}
          </div>
          <div className="relative w-full overflow-hidden">
            <div className={`whitespace-nowrap inline-flex gap-12 font-medium ${lang === 'ur' ? 'animate-marquee-rtl font-urdu text-sm' : 'animate-marquee text-xs'}`}>
              {announcements.map((ann, idx) => (
                <span key={ann.id} className="inline-flex items-center gap-2 text-amber-900 dark:text-amber-300 cursor-pointer" onClick={() => scrollToSection('announcements')}>
                  <span className="text-xs">✦</span>
                  {lang === 'ur' ? ann.textUr : ann.textEn}
                </span>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Hero Section */}
      <section id="hero" className="relative min-h-[85vh] lg:min-h-[90vh] flex items-center justify-center overflow-hidden bg-slate-950 text-white px-4 sm:px-6 lg:px-8 py-20">
        
        {/* Parallax Majestic Islamic Architectural Overlay Background */}
        <div className="absolute inset-0 z-0">
          <div className="absolute inset-0 bg-gradient-to-b from-slate-950/60 via-slate-950/80 to-slate-950 z-10" />
          {/* Aesthetic real high-resolution mosque minarets background */}
          <img
            src="https://images.unsplash.com/photo-1564507592333-c60657eea523?auto=format&fit=crop&q=80&w=2000"
            alt="Darul Uloom Islamic Architecture"
            className="w-full h-full object-cover opacity-35 object-center transform scale-105 hover:scale-100 transition-all duration-10000"
          />
          {/* Majestic Animated Silhouette Watermark Overlay */}
          <div className="absolute bottom-0 right-0 left-0 h-48 bg-[url('data:image/svg+xml;utf8,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 1200 120%22 preserveAspectRatio=%22none%22 style=%22fill:%23020617;%22><path d=%22M0,0V120H1200V0C1100,50,900,105,600,105C300,105,100,50,0,0Z%22/></svg>')] bg-cover opacity-100 z-10" />
        </div>

        {/* Floating Sacred Islamic Pattern Background */}
        <div className="absolute inset-0 bg-[radial-gradient(#c5a059_0.8px,transparent_0.8px)] [background-size:20px_20px] opacity-15 z-0" />

        <div className="relative z-20 max-w-5xl mx-auto text-center space-y-8">
          
          {/* Top small greeting tag */}
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full backdrop-blur-md bg-white/10 border border-white/20 text-white text-xs sm:text-sm font-semibold text-amber-300 font-arabic tracking-wide"
          >
            بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ 
          </motion.div>

          {/* Majestic Main Headline */}
          <div className="space-y-4">
            <motion.h2
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.7, delay: 0.2 }}
              className={`text-amber-400 uppercase font-extrabold tracking-widest ${lang === 'ur' ? 'font-urdu text-xl' : 'font-sans text-xs sm:text-sm'}`}
            >
              {lang === 'ur' ? 'جامعہ قدیم و جدید کا عظیم امتزاج' : 'Welcome to the Oasis of Classical Sacred Knowledge'}
            </motion.h2>

            <motion.h1
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.3 }}
              className={`text-3xl sm:text-5xl lg:text-7xl font-extrabold leading-tight text-white ${lang === 'ur' ? 'font-urdu leading-[1.3]' : 'font-sans tracking-tight'}`}
            >
              {lang === 'ur' ? 'دار العلوم رضاِ غوثِ اعظم' : 'Darul Uloom Raza-E-Gous-E-Azam'}
            </motion.h1>

            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 1, delay: 0.5 }}
              className={`max-w-2xl mx-auto text-slate-300 text-sm sm:text-lg lg:text-xl leading-relaxed ${lang === 'ur' ? 'font-urdu leading-loose pt-2' : 'font-sans font-light'}`}
            >
              {lang === 'ur' 
                ? 'تاج نگر، ہاویری، کرناٹک ہند کی ایک معتمد اور قدیمی دینی درسگاہ جہاں روحانیت، فضیلت، حفظ اور عالمیت کے مضامین کی بہترین تدریس ہوتی ہے۔'
                : 'A distinguished sanctuary of Islamic theology, scripture sciences, and literary heritage. Anchored upon deep spiritual foundations, educating generations in the pristine path of universal guidance.'}
            </motion.p>
          </div>

          {/* Custom CTA Action Buttons with micro-interactions */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.7 }}
            className="flex flex-col sm:flex-row justify-center items-center gap-4 pt-4"
          >
            {/* Admission Open trigger */}
            <button
               onClick={() => scrollToSection('contact')}
               className="w-full sm:w-auto bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-bold px-8 py-4 rounded-xl shadow-lg shadow-amber-500/20 hover:shadow-amber-500/40 hover:-translate-y-0.5 transition active:translate-y-0 flex items-center justify-center gap-2.5 cursor-pointer text-sm sm:text-base"
            >
              <CheckCircle className="w-5 h-5 flex-shrink-0" />
              <span className={lang === 'ur' ? 'font-urdu leading-none' : ''}>{t.admissionOpen}</span>
            </button>

            {/* Donate Now trigger */}
            <button
              onClick={() => scrollToSection('donation')}
              className="w-full sm:w-auto bg-transparent hover:bg-white/10 text-white font-bold px-8 py-4 rounded-xl border-2 border-white/30 hover:border-white transition flex items-center justify-center gap-2.5 cursor-pointer text-sm sm:text-base backdrop-blur-sm"
            >
              <Heart className="w-5 h-5 text-amber-400 flex-shrink-0 fill-amber-400/20" />
              <span className={lang === 'ur' ? 'font-urdu leading-none' : ''}>{t.donateNow}</span>
            </button>
          </motion.div>

          {/* Quick Stats Grid positioned underneath the hero block */}
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.9 }}
            className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-5xl mx-auto pt-10"
          >
            {[
              { labelEn: "Enrolled Students", labelUr: "حفظ و تعلیم کے طلبہ", valVal: "350+", color: "text-amber-400" },
              { labelEn: "Staff & Scholars", labelUr: "شیوخ و اساتذہ", valVal: "18+", color: "text-emerald-400" },
              { labelEn: "Classrooms & Halqas", labelUr: "تعلیمی حلقے و کمرے", valVal: "12+", color: "text-blue-400" },
              { labelEn: "Established Year", labelUr: "سالِ سنگِ بنیاد", valVal: "2004", color: "text-purple-400" },
            ].map((st, sidx) => (
              <div key={sidx} className="bg-white/5 border border-white/10 backdrop-blur-md rounded-2xl p-4 transform hover:scale-105 hover:bg-white/10 transition duration-300">
                <div className={`text-2xl sm:text-3.5xl font-black ${st.color} font-mono`}>{st.valVal}</div>
                <div className={`text-slate-300 text-xs mt-1 leading-snug ${lang === 'ur' ? 'font-urdu text-[11px]' : 'font-sans uppercase font-medium tracking-wide text-[10px]'}`}>
                  {lang === 'ur' ? st.labelUr : st.labelEn}
                </div>
              </div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Daily Congregation Prayer Timings Section (Highly dynamic & Interactive) */}
      <section className="relative -mt-8 z-30 max-w-6xl mx-auto px-4">
        <div className={`rounded-3xl shadow-xl overflow-hidden border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 sm:p-8 transition-all ${darkMode ? 'shadow-emerald-950/20' : 'shadow-slate-200'}`}>
          <div className="flex flex-col md:flex-row justify-between items-center gap-4 mb-6 pb-6 border-b border-slate-100 dark:border-slate-800">
            <div>
              <h2 className={`text-2xl font-extrabold text-emerald-800 dark:text-emerald-400 flex items-center gap-2.5 ${lang === 'ur' ? 'font-urdu' : ''}`}>
                <Clock className="w-6 h-6 text-amber-500 animate-pulse" />
                <span>{t.prayerTimesTitle}</span>
              </h2>
              <p className="text-slate-500 dark:text-slate-400 text-xs sm:text-sm mt-1">
                {lang === 'ur' ? 'رواں تعلیمی سال مروجہ اوقات برائے ضلع ہاویری ومضافات' : 'Congregational (Iqamah) times standard for district Haveri'}
              </p>
            </div>
            
            {/* Live Indicator of the NEXT UPCOMING PRAYER */}
            <div className="bg-emerald-500/10 border border-emerald-500/30 text-emerald-800 dark:text-emerald-300 rounded-2xl px-5 py-3 text-sm flex items-center gap-3">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping"></span>
              <div className="text-right">
                <span className={`text-[11px] block text-slate-400 uppercase tracking-widest ${lang === 'ur' ? 'font-urdu' : ''}`}>
                  {lang === 'ur' ? 'اگلی نماز باجماعت:' : 'Next Congregation Prayer:'}
                </span>
                <span className={`font-bold block text-sm sm:text-base ${lang === 'ur' ? 'font-urdu' : ''}`}>
                  {lang === 'ur' ? nextPrayer.nameUr : nextPrayer.name} • <span className="font-mono text-amber-500">{nextPrayer.time}</span>
                </span>
              </div>
              <div className="bg-emerald-500/20 dark:bg-emerald-500/30 rounded-lg p-1.5 text-xs text-center font-mono">
                {lang === 'ur' ? 'تقریباً' : 'approx'} <span className="font-bold underline">{nextPrayer.minutesLeft}</span> {lang === 'ur' ? 'منٹ بعد' : 'mins remaining'}
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
            {defaultPrayerTimes.map((pr, pidx) => {
              const isNext = pr.name === nextPrayer.name;
              return (
                <div
                  key={pidx}
                  className={`rounded-2xl p-4 text-center border transition-all ${
                    isNext
                      ? 'bg-gradient-to-b from-emerald-800 to-emerald-950 border-amber-400 text-white translate-y-[-4px] shadow-lg ring-4 ring-emerald-500/20'
                      : 'bg-slate-50 dark:bg-slate-800/40 border-slate-100 dark:border-slate-800 text-slate-800 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800/80'
                  }`}
                >
                  <span className={`text-[10px] block font-mono tracking-wider ${isNext ? 'text-amber-300 font-extrabold uppercase' : 'text-slate-400'}`}>
                    {pr.arabic}
                  </span>
                  <span className={`text-base sm:text-lg font-extrabold block mt-1.5 ${lang === 'ur' ? 'font-urdu' : 'font-sans'}`}>
                    {lang === 'ur' ? pr.nameUr : pr.name}
                  </span>
                  <span className={`text-sm sm:text-base font-bold block mt-1 font-mono ${isNext ? 'text-amber-100' : 'text-emerald-700 dark:text-emerald-400'}`}>
                    {pr.time}
                  </span>
                  {isNext && (
                    <span className="inline-block mt-2 bg-amber-400 text-slate-950 text-[9px] uppercase font-black px-2 py-0.5 rounded-full">
                      {lang === 'ur' ? 'نقشِ وقت' : 'NEXT'}
                    </span>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16">
        
        {/* About heading banner */}
        <div className="text-center max-w-3xl mx-auto space-y-3">
          <span className="text-emerald-600 dark:text-emerald-400 text-sm font-bold uppercase tracking-widest block">
            {lang === 'ur' ? 'اصلاحِ عقائد و معاشرہ' : 'Spiritual Academic Canopy'}
          </span>
          <h2 className={`text-3xl sm:text-5xl font-extrabold text-slate-900 dark:text-white ${lang === 'ur' ? 'font-urdu leading-snug' : 'tracking-tight'}`}>
            {t.aboutTitle}
          </h2>
          <p className={`text-slate-500 dark:text-slate-400 text-sm sm:text-base leading-relaxed ${lang === 'ur' ? 'font-urdu pt-1.5' : ''}`}>
            {t.aboutSubtitle}
          </p>
          <div className="w-24 h-1.5 bg-gradient-to-r from-emerald-600 to-amber-500 mx-auto rounded-full mt-4" />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* History Block Left */}
          <div className="lg:col-span-7 space-y-6">
            <div className="flex gap-4 items-start">
              <div className="p-3.5 bg-emerald-100 dark:bg-emerald-950/40 rounded-2xl text-emerald-800 dark:text-emerald-300">
                <HistoryIcon className="w-6 h-6" />
              </div>
              <div className="space-y-3">
                <h3 className={`text-xl sm:text-2xl font-bold text-slate-800 dark:text-slate-100 ${lang === 'ur' ? 'font-urdu' : ''}`}>
                  {t.aboutHistoryTitle}
                </h3>
                <p className={`text-slate-600 dark:text-slate-300 text-sm sm:text-base leading-relaxed ${lang === 'ur' ? 'font-urdu text-[15px] leading-loose' : ''}`}>
                  {t.aboutHistoryText}
                </p>
              </div>
            </div>

            {/* Quality Statement (No Tech Larping / Pure Clean facts) */}
            <div className="p-5 rounded-2xl-custom bg-emerald-50 dark:bg-emerald-950/10 border border-emerald-500/10 flex items-start gap-4">
              <Award className="w-8 h-8 text-amber-500 flex-shrink-0" />
              <div>
                <h4 className={`text-sm sm:text-base font-semibold text-emerald-900 dark:text-emerald-400 uppercase ${lang === 'ur' ? 'font-urdu' : ''}`}>
                  {lang === 'ur' ? 'مسلکِ اعتدال و عقیدہِ حقہ' : 'Uncompromising Theological Foundations'}
                </h4>
                <p className={`text-slate-500 dark:text-slate-400 text-xs sm:text-sm mt-1 leading-relaxed ${lang === 'ur' ? 'font-urdu' : ''}`}>
                  {lang === 'ur' 
                    ? 'دارالعلوم مسلکِ اہلسنت والجماعت حنفی کی ترویج اور مساجد کے لیے صالح امام، قاری اور معلم پیدا کرنے میں سرگرمِ عمل ہے۔' 
                    : 'Ahl-as-Sunnah Wal-Jamaah (Hanafi creed) principles guide our educational efforts, fostering tolerance and academic excellence.'}
                </p>
              </div>
            </div>
          </div>

          {/* Core Vision & Mission Right Cards */}
          <div className="lg:col-span-5 space-y-6">
            {/* Mission Card */}
            <div className="bg-white dark:bg-slate-900 border border-slate-150 dark:border-slate-800 rounded-3xl p-6 shadow-sm relative overflow-hidden group">
              <div className="absolute top-0 right-0 w-24 h-24 bg-emerald-500/5 rounded-bl-full transform group-hover:scale-110 transition duration-300" />
              <div className="flex gap-4 items-start relative z-10">
                <div className="w-12 h-12 bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 flex items-center justify-center rounded-xl flex-shrink-0">
                  <Compass className="w-6 h-6" />
                </div>
                <div className="space-y-2">
                  <h4 className={`text-lg sm:text-xl font-bold text-slate-800 dark:text-slate-100 ${lang === 'ur' ? 'font-urdu' : ''}`}>
                    {t.missionTitle}
                  </h4>
                  <p className={`text-slate-500 dark:text-slate-400 text-xs sm:text-sm leading-relaxed ${lang === 'ur' ? 'font-urdu text-[14px]' : ''}`}>
                    {t.missionText}
                  </p>
                </div>
              </div>
            </div>

            {/* Vision Card */}
            <div className="bg-white dark:bg-slate-900 border border-slate-150 dark:border-slate-800 rounded-3xl p-6 shadow-sm relative overflow-hidden group">
              <div className="absolute top-0 right-0 w-24 h-24 bg-amber-500/5 rounded-bl-full transform group-hover:scale-110 transition duration-300" />
              <div className="flex gap-4 items-start relative z-10">
                <div className="w-12 h-12 bg-amber-500/10 text-amber-600 dark:text-amber-400 flex items-center justify-center rounded-xl flex-shrink-0">
                  <Sparkles className="w-6 h-6" />
                </div>
                <div className="space-y-2">
                  <h4 className={`text-lg sm:text-xl font-bold text-slate-800 dark:text-slate-100 ${lang === 'ur' ? 'font-urdu' : ''}`}>
                    {t.visionTitle}
                  </h4>
                  <p className={`text-slate-500 dark:text-slate-400 text-xs sm:text-sm leading-relaxed ${lang === 'ur' ? 'font-urdu text-[14px]' : ''}`}>
                    {t.visionText}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Courses/Curriculum Section */}
      <section id="courses" className="bg-slate-100 dark:bg-slate-950-custom py-20 bg-emerald-950/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16">
          
          <div className="text-center max-w-3xl mx-auto space-y-3">
            <span className="text-amber-600 dark:text-amber-400 text-sm font-bold uppercase tracking-widest block">
              {lang === 'ur' ? 'نصاب برائے اسلامی تعلیم' : 'Sacred Fields of Intimate Science'}
            </span>
            <h2 className={`text-3xl sm:text-5xl font-extrabold text-slate-900 dark:text-white ${lang === 'ur' ? 'font-urdu leading-snug' : 'tracking-tight'}`}>
              {t.coursesTitle}
            </h2>
            <p className={`text-slate-500 dark:text-slate-400 text-sm sm:text-base leading-relaxed ${lang === 'ur' ? 'font-urdu pt-1.5' : ''}`}>
              {t.coursesSubtitle}
            </p>
            <div className="w-24 h-1.5 bg-gradient-to-r from-emerald-600 to-amber-500 mx-auto rounded-full mt-4" />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {courses.map((course, idx) => {
              const IconComp = IconMap[course.icon] || BookOpen;
              return (
                <div
                  key={course.id}
                  className="bg-white dark:bg-slate-900 border border-slate-150 dark:border-slate-800 rounded-3xl p-6 shadow-sm hover:shadow-md hover:translate-y-[-2px] transition duration-300 flex flex-col justify-between"
                >
                  <div className="space-y-4">
                    {/* Course Card Top Icon and Duration Tag */}
                    <div className="flex items-center justify-between">
                      <div className="w-12 h-12 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-300 flex items-center justify-center shadow-inner">
                        <IconComp className="w-6 h-6" />
                      </div>
                      <span className={`px-3 py-1 rounded-full text-xs font-semibold bg-emerald-500/10 text-emerald-800 dark:text-emerald-300 ${lang === 'ur' ? 'font-urdu text-[11px]' : ''}`}>
                         {lang === 'ur' ? course.durationUr : course.durationEn}
                      </span>
                    </div>

                    {/* Arabic Scripture subtitle signature for premium look */}
                    <div className="font-arabic text-amber-600 text-xs sm:text-sm font-bold opacity-90 block">
                      {course.arabicName}
                    </div>

                    <div className="space-y-2">
                      <h3 className={`text-xl font-extrabold text-slate-800 dark:text-slate-100 ${lang === 'ur' ? 'font-urdu' : ''}`}>
                        {lang === 'ur' ? course.titleUr : course.titleEn}
                      </h3>
                      <p className={`text-slate-500 dark:text-slate-400 text-xs sm:text-sm leading-relaxed ${lang === 'ur' ? 'font-urdu text-[13px] leading-loose' : 'line-clamp-3'}`}>
                        {lang === 'ur' ? course.descUr : course.descEn}
                      </p>
                    </div>
                  </div>

                  <div className="pt-6 border-t border-slate-50 dark:border-slate-800 mt-6 flex items-center justify-between">
                    <span className="text-[10px] text-slate-400 uppercase font-mono">
                      {lang === 'ur' ? 'شعبہ تعلیمی' : 'Academic Course'}
                    </span>
                    <button 
                      onClick={() => scrollToSection('contact')} 
                      className="text-xs font-bold text-emerald-700 dark:text-emerald-400 hover:underline cursor-pointer flex items-center gap-1"
                    >
                      <span>{lang === 'ur' ? 'تفصیل برائے داخلہ' : 'Inquire Admission'}</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Facilities Section */}
      <section id="facilities" className="py-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16">
        
        <div className="text-center max-w-3xl mx-auto space-y-3">
          <span className="text-emerald-600 dark:text-emerald-400 text-sm font-bold uppercase tracking-widest block">
            {lang === 'ur' ? 'طلبہ کے لیے مروجہ انتظام' : 'Campus Infrastructure'}
          </span>
          <h2 className={`text-3xl sm:text-5xl font-extrabold text-slate-900 dark:text-white ${lang === 'ur' ? 'font-urdu leading-snug' : 'tracking-tight'}`}>
            {t.facilitiesSubtitle}
          </h2>
          <p className="text-slate-500 dark:text-slate-400 text-xs sm:text-sm">
            {lang === 'ur' ? 'تعلیمی ارتکاز اور سکون کی غرض سے جامعہ کا مربوط ماڈل' : 'Dedicated to providing a quiet, supportive study environment'}
          </p>
          <div className="w-24 h-1.5 bg-gradient-to-r from-emerald-600 to-amber-500 mx-auto rounded-full mt-4" />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {facilities.map((fac) => {
            const IconComp = IconMap[fac.icon] || Sparkles;
            return (
              <div 
                key={fac.id}
                className="group relative bg-white dark:bg-slate-900 border border-slate-150 dark:border-slate-800 rounded-3xl p-6 shadow-sm hover:shadow-lg hover:border-emerald-500/20 dark:hover:border-emerald-500/20 transition-all duration-350"
              >
                <div className="absolute -inset-px rounded-3xl bg-gradient-to-tr from-emerald-500/5 to-amber-500/5 opacity-0 group-hover:opacity-100 transition duration-300" />
                
                <div className="relative z-10 space-y-4">
                  <div className="w-12 h-12 rounded-2xl bg-amber-500/10 text-amber-600 dark:text-amber-400 flex items-center justify-center transform group-hover:scale-110 transition duration-300">
                    <IconComp className="w-5.5 h-5.5" />
                  </div>
                  <h3 className={`text-xl font-extrabold text-slate-800 dark:text-slate-100 ${lang === 'ur' ? 'font-urdu' : ''}`}>
                    {lang === 'ur' ? fac.titleUr : fac.titleEn}
                  </h3>
                  <p className={`text-slate-500 dark:text-slate-400 text-xs sm:text-sm leading-relaxed ${lang === 'ur' ? 'font-urdu text-[13px] leading-loose' : ''}`}>
                    {lang === 'ur' ? fac.descUr : fac.descEn}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* Photo Gallery Section with Interactive Lightbox */}
      <section id="gallery" className="py-20 bg-slate-100/50 dark:bg-slate-900/50 border-t border-b border-slate-200 dark:border-slate-850">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
          
          <div className="text-center max-w-3xl mx-auto space-y-3">
            <span className="text-amber-600 dark:text-amber-400 text-sm font-bold uppercase tracking-widest block">
              {lang === 'ur' ? 'دار العلوم کا تصویری خاکہ' : 'Pictorial Glimpses'}
            </span>
            <h2 className={`text-3xl sm:text-5xl font-extrabold text-slate-900 dark:text-white ${lang === 'ur' ? 'font-urdu leading-snug' : 'tracking-tight'}`}>
              {t.galleryTitle}
            </h2>
            <p className="text-slate-500 dark:text-slate-400 text-xs sm:text-sm">
              {t.gallerySubtitle}
            </p>
            <div className="w-24 h-1.5 bg-gradient-to-r from-emerald-600 to-amber-500 mx-auto rounded-full mt-4" />
          </div>

          {/* Core Category Filters */}
          <div className="flex flex-wrap justify-center gap-2 max-w-xl mx-auto pt-4">
            {['All', 'Classes', 'Campus', 'Events'].map(cat => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-4 py-1.5 rounded-full text-xs font-semibold cursor-pointer transition ${
                  selectedCategory === cat
                    ? 'bg-emerald-700 text-white shadow-sm'
                    : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-700 hover:bg-slate-50'
                }`}
              >
                {lang === 'ur'
                  ? cat === 'All' ? 'تمام جھلکیاں' : cat === 'Classes' ? 'حلقہِ تدریس' : cat === 'Campus' ? 'عمارت و کتب خانہ' : 'تقاریبِ ختمِ بخاری'
                  : cat
                }
              </button>
            ))}
          </div>

          {/* Photo Grid with Interactive click lightbox triggers */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 pt-4">
            {filteredGallery.map((item, idx) => (
              <div
                key={item.id}
                onClick={() => setLightboxIndex(idx)}
                className="group relative rounded-3xl overflow-hidden shadow-sm aspect-[4/3] bg-slate-200 dark:bg-slate-800 cursor-pointer transform hover:scale-[1.02] transition-all duration-300"
              >
                <img
                  src={item.image}
                  alt={item.titleEn}
                  className="w-full h-full object-cover transition duration-500 group-hover:scale-105"
                  referrerPolicy="no-referrer"
                />
                
                {/* Visual Glass gradient hover overlay banner */}
                <div className="absolute inset-0 bg-gradient-to-t from-slate-900/90 via-slate-900/40 to-transparent opacity-0 group-hover:opacity-100 transition duration-300 flex flex-col justify-end p-6">
                  <span className="text-[10px] text-amber-400 uppercase font-mono tracking-wider mb-1">
                    {lang === 'ur' ? item.categoryUr : item.categoryEn}
                  </span>
                  <h3 className={`text-white text-base font-bold ${lang === 'ur' ? 'font-urdu text-[14px] leading-loose' : 'font-sans'}`}>
                    {lang === 'ur' ? item.titleUr : item.titleEn}
                  </h3>
                  <p className="text-white/70 text-[10px] mt-1 hover:underline">
                    {lang === 'ur' ? 'بڑا منظر دیکھنے کے لیے کلک کریں 🔍' : 'Click to zoom and view full 🔍'}
                  </p>
                </div>

                {/* Always-on subtle badge for mobile users who can't hover */}
                <div className="absolute bottom-3 left-3 bg-slate-950/70 backdrop-blur-md px-3 py-1 rounded-full text-[10px] text-white/95 group-hover:opacity-0 transition">
                  {lang === 'ur' ? item.titleUr.substring(0, 30) + '...' : item.titleEn}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Interactive Lightbox Portal (Framer-Motion animation enabled) */}
      <AnimatePresence>
        {lightboxIndex !== null && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/95 backdrop-blur-md flex items-center justify-center p-4"
          >
            <button
              onClick={() => setLightboxIndex(null)}
              className="absolute top-6 right-6 p-2 rounded-full bg-white/10 hover:bg-white/20 text-white cursor-pointer transition z-55"
              aria-label="Close Lightbox"
            >
              <X className="w-8 h-8" />
            </button>

            <div className="max-w-5xl w-full flex flex-col items-center gap-4 relative">
              {/* Previous Slide Button */}
              <button
                onClick={prevGalleryItem}
                className="absolute left-2 md:-left-16 p-2.5 rounded-full bg-white/10 hover:bg-white/20 text-white cursor-pointer z-55"
                title="Previous Image"
              >
                <ArrowLeft className="w-6 h-6" />
              </button>

              <div className="relative max-h-[75vh] max-w-full overflow-hidden rounded-2xl-custom border border-white/20">
                <img
                  src={filteredGallery[lightboxIndex].image}
                  alt={filteredGallery[lightboxIndex].titleEn}
                  className="max-h-[75vh] w-auto max-w-full object-contain"
                  referrerPolicy="no-referrer"
                />
              </div>

              {/* Title & Caption block below */}
              <div className="text-center text-white max-w-xl space-y-1">
                <span className="text-xs text-amber-300 font-mono uppercase tracking-widest block">
                  {lang === 'ur' ? filteredGallery[lightboxIndex].categoryUr : filteredGallery[lightboxIndex].categoryEn}
                </span>
                <h3 className={`text-lg sm:text-xl font-bold ${lang === 'ur' ? 'font-urdu leading-loose' : 'font-sans'}`}>
                  {lang === 'ur' ? filteredGallery[lightboxIndex].titleUr : filteredGallery[lightboxIndex].titleEn}
                </h3>
                <p className="text-xs text-slate-400">
                  {lightboxIndex + 1} / {filteredGallery.length}
                </p>
              </div>

              {/* Next Slide Button */}
              <button
                onClick={nextGalleryItem}
                className="absolute right-2 md:-right-16 p-2.5 rounded-full bg-white/10 hover:bg-white/20 text-white cursor-pointer z-55"
                title="Next Image"
              >
                <ArrowRight className="w-6 h-6" />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Documents Section (With real simulation state) */}
      <section id="documents" className="py-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16">
        
        <div className="text-center max-w-3xl mx-auto space-y-3">
          <span className="text-emerald-600 dark:text-emerald-400 text-sm font-bold uppercase tracking-widest block">
            {lang === 'ur' ? 'اہم دستاویزات برائے مطالعہ' : 'Compliance & Documents Center'}
          </span>
          <h2 className={`text-3xl sm:text-5xl font-extrabold text-slate-900 dark:text-white ${lang === 'ur' ? 'font-urdu leading-snug' : 'tracking-tight'}`}>
            {t.documentsTitle}
          </h2>
          <p className="text-slate-500 dark:text-slate-400 text-xs sm:text-sm">
            {t.documentsSubtitle}
          </p>
          <div className="w-24 h-1.5 bg-gradient-to-r from-emerald-600 to-amber-500 mx-auto rounded-full mt-4" />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {documents.map((doc) => {
            const isThisDownloading = downloadingId === doc.id;
            return (
              <div
                key={doc.id}
                className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm flex flex-col justify-between hover:shadow-md transition"
              >
                <div className="space-y-4">
                  <div className="w-10 h-10 rounded-xl bg-orange-500/10 text-orange-600 dark:text-orange-400 flex items-center justify-center">
                    <Download className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 font-mono uppercase block mb-1">
                      {lang === 'ur' ? doc.dateStrUr : doc.dateStrEn}
                    </span>
                    <h3 className={`text-base font-bold text-slate-800 dark:text-slate-100 ${lang === 'ur' ? 'font-urdu text-[14px] leading-loose' : 'line-clamp-2'}`}>
                      {lang === 'ur' ? doc.titleUr : doc.titleEn}
                    </h3>
                  </div>
                </div>

                <div className="pt-6 border-t border-slate-50 dark:border-slate-800 mt-6 space-y-3">
                  <div className="flex justify-between items-center text-xs text-slate-500">
                    <span>{doc.fileSize}</span>
                    <span className="text-emerald-600 dark:text-emerald-400 font-bold uppercase text-[9px]">Verified PDF</span>
                  </div>

                  {/* Active Simulator Loader Bar */}
                  {isThisDownloading ? (
                    <div className="space-y-1.5">
                      <div className="flex justify-between text-[11px] font-mono">
                        <span className="text-slate-400">Downloading...</span>
                        <span className="font-bold text-emerald-600">{downloadProgress}%</span>
                      </div>
                      <div className="w-full bg-slate-100 dark:bg-slate-800 h-1.5 rounded-full overflow-hidden">
                        <div className="bg-emerald-500 h-full transition-all duration-300" style={{ width: `${downloadProgress}%` }} />
                      </div>
                    </div>
                  ) : (
                    <button
                      onClick={() => startSimulationDownload(doc)}
                      className="w-full bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-100 py-2.5 rounded-xl text-xs font-bold hover:bg-emerald-600 hover:text-white dark:hover:bg-emerald-600 transition cursor-pointer flex items-center justify-center gap-1.5"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>{lang === 'ur' ? 'ڈاؤن لوڈ کریں' : 'Download Document'}</span>
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* Donation Section (With full Bank Account copy features and QR) */}
      <section id="donation" className="py-20 bg-emerald-950 text-white relative overflow-hidden">
        
        {/* Sacred mosque background watermark with beautiful opacity */}
        <div className="absolute inset-0 z-0">
          <div className="absolute inset-0 bg-emerald-950/95" />
          <div className="absolute inset-0 bg-[radial-gradient(#c5a059_0.5px,transparent_0.5px)] [background-size:16px_16px] opacity-10" />
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 lg:grid-cols-12 gap-12">
          
          {/* Donation Left: Spiritual Appeal */}
          <div className="lg:col-span-7 space-y-6 flex flex-col justify-center">
            
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-md bg-amber-500/10 text-amber-300 border border-amber-500/25 text-xs text-[11px] tracking-widest uppercase font-semibold">
              ✨ {lang === 'ur' ? 'عہدِ خیرات و زکات' : 'SADAQAH, JARIYAH & ZAKAT WELCOME'}
            </div>

            <h2 className={`text-3xl sm:text-5xl font-extrabold text-white ${lang === 'ur' ? 'font-urdu leading-[1.3]' : 'tracking-tight'}`}>
              {t.donationTitle}
            </h2>
            <p className={`text-emerald-100/80 text-sm sm:text-base leading-relaxed ${lang === 'ur' ? 'font-urdu text-[15px] leading-loose' : ''}`}>
              {lang === 'ur' 
                ? 'ہمارا دار العلوم خالص دینی جذبے کے تحت غریب، یتیم اور نادار طلبہ کو بلا معاوضہ طعام، قیام اور کتبِ نصاب مہیا کرتا ہے۔ قرآن مجید کی اشاعت اور مساجد کی دیکھ بھال کے ان مبارک منصوبوں میں اپنا ہاتھ بٹا کر اللہ رب العزت کی رضا حاصل کریں۔'
                : 'Darul Uloom Raza-E-Gous-E-Azam supports around 350+ students with complimentary textbook kits, lodging, uniform requirements, and highly professional guidance free of charge. Contribute deeply to this continuous stream of rewards.' 
              }
            </p>

            {/* Quote on charity */}
            <blockquote className="border-l-4 border-amber-400 pl-4 py-1 text-slate-300 font-arabic text-sm sm:text-base italic">
              "مَثَلُ الَّذِينَ يُنفِقُونَ أَمْوَالَهُمْ فِي سَبِيلِ اللَّهِ كَمَثَلِ حَبَّةٍ أَنبَتَتْ سَبْعَ سَنَابِلَ..."
              <span className="block text-xs mt-1 text-amber-300 font-sans not-italic">
                — Surah Al-Baqarah: 261
              </span>
            </blockquote>

            {/* Educational Sponsorship cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
              <div className="p-4 bg-white/5 border border-white/10 rounded-2.5xl flex items-start gap-3.5">
                <Heart className="w-5 h-5 text-amber-400 fill-amber-400/20 mt-1 flex-shrink-0" />
                <div>
                  <span className={`text-[11px] text-emerald-300 font-mono uppercase block ${lang === 'ur' ? 'font-urdu' : ''}`}>
                    {lang === 'ur' ? 'کفالت برائے ایک یتیم بچہ' : 'Sponsor 1 Student'}
                  </span>
                  <span className="text-lg font-extrabold block text-white font-mono">₹ 1,500 / Month</span>
                </div>
              </div>

              <div className="p-4 bg-white/5 border border-white/10 rounded-2.5xl flex items-start gap-3.5">
                <Sparkles className="w-5 h-5 text-amber-400 mt-1 flex-shrink-0" />
                <div>
                  <span className={`text-[11px] text-emerald-300 font-mono uppercase block ${lang === 'ur' ? 'font-urdu' : ''}`}>
                    {lang === 'ur' ? 'غذا وطعام برائے ایک یوم' : 'Daily Meals Sponsor'}
                  </span>
                  <span className="text-lg font-extrabold block text-white font-mono">₹ 5,000 / Day</span>
                </div>
              </div>
            </div>
          </div>

          {/* Donation Right: Form placeholder QR and copy physical info */}
          <div className="lg:col-span-5 bg-white text-slate-800 rounded-3xl p-6 sm:p-8 shadow-xl relative overflow-hidden flex flex-col justify-between">
            <div className="space-y-6">
              
              <div className="text-center pb-4 border-b border-slate-100 flex flex-col items-center">
                <h3 className={`text-lg sm:text-xl font-bold text-slate-800 ${lang === 'ur' ? 'font-urdu' : ''}`}>
                  {lang === 'ur' ? 'بینک اکاؤنٹ تفصیلات' : 'Bank Account Information'}
                </h3>
                <p className="text-slate-500 text-xs mt-1">
                  {lang === 'ur' ? 'براہِ راست منتقلی کے لیے تفصیل کاپی کریں' : 'Click any field below to copy immediately'}
                </p>
              </div>

              {/* Direct bank details with click copy action fields */}
              <div className="space-y-3 font-sans">
                
                <div 
                  onClick={() => triggerCopy('Darul Uloom Raza-E-Gous-E-Azam', 'name')}
                  className="p-3 bg-slate-50 hover:bg-emerald-50 rounded-xl border border-slate-150 cursor-pointer transition flex items-center justify-between"
                  title="Click to copy name"
                >
                  <div className="text-left">
                    <span className="text-[10px] text-slate-400 font-bold uppercase block">Beneficiary Name</span>
                    <span className="text-sm font-bold text-slate-800">Darul Uloom Raza-E-Gous-E-Azam</span>
                  </div>
                  {copiedField === 'name' ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4 text-slate-400" />}
                </div>

                <div 
                  onClick={() => triggerCopy('50200085432654', 'account')}
                  className="p-3 bg-slate-50 hover:bg-emerald-50 rounded-xl border border-slate-150 cursor-pointer transition flex items-center justify-between"
                  title="Click to copy account number"
                >
                  <div className="text-left font-mono">
                    <span className="text-[10px] text-slate-400 font-sans font-bold uppercase block">Account Number</span>
                    <span className="text-base font-bold text-emerald-700">50200085432654</span>
                  </div>
                  {copiedField === 'account' ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4 text-slate-400" />}
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div 
                    onClick={() => triggerCopy('HDFC0000329', 'ifsc')}
                    className="p-3 bg-slate-50 hover:bg-emerald-50 rounded-xl border border-slate-150 cursor-pointer transition flex items-center justify-between"
                    title="Click to copy IFSC Code"
                  >
                    <div className="text-left font-mono">
                      <span className="text-[10px] text-slate-400 font-sans font-bold uppercase block">IFSC Code</span>
                      <span className="text-sm font-bold text-slate-800">HDFC0000329</span>
                    </div>
                    {copiedField === 'ifsc' ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-3.5 h-3.5 text-slate-400" />}
                  </div>

                  <div 
                    onClick={() => triggerCopy('Haveri Branch', 'branch')}
                    className="p-3 bg-slate-50 hover:bg-emerald-50 rounded-xl border border-slate-150 cursor-pointer transition flex items-center justify-between"
                    title="Click to copy branch"
                  >
                    <div className="text-left">
                      <span className="text-[10px] text-slate-400 font-bold uppercase block">Branch Venue</span>
                      <span className="text-xs font-bold text-slate-800 line-clamp-1">Haveri, Karnataka</span>
                    </div>
                    {copiedField === 'branch' ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-3.5 h-3.5 text-slate-400" />}
                  </div>
                </div>

                <div 
                  onClick={() => triggerCopy('darululoomhaveri@upi', 'upi')}
                  className="p-3 bg-slate-50 hover:bg-emerald-50 rounded-xl border border-slate-150 cursor-pointer transition flex items-center justify-between"
                  title="Click to copy UPI ID"
                >
                  <div className="text-left font-mono">
                    <span className="text-[10px] text-slate-400 font-sans font-bold uppercase block">UPI ID / GPAY / PHONEPE</span>
                    <span className="text-sm font-bold text-amber-600">darululoomhaveri@upi</span>
                  </div>
                  {copiedField === 'upi' ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4 text-slate-400" />}
                </div>
              </div>

              {/* QR Indicator placeholder as requested */}
              <div className="p-4 bg-emerald-50 rounded-2.5xl flex flex-col sm:flex-row items-center gap-4 border border-emerald-100">
                <div className="w-24 h-24 bg-white p-2 border border-slate-200 rounded-xl flex items-center justify-center flex-shrink-0 shadow-inner">
                  {/* Embedded inline vector QR SVG */}
                  <svg viewBox="0 0 100 100" className="w-full h-full text-emerald-950">
                    <rect x="0" y="0" width="100" height="100" fill="none" />
                    {/* Corners */}
                    <rect x="5" y="5" width="25" height="25" fill="currentColor" />
                    <rect x="10" y="10" width="15" height="15" fill="white" />
                    <rect x="70" y="5" width="25" height="25" fill="currentColor" />
                    <rect x="75" y="10" width="15" height="15" fill="white" />
                    <rect x="5" y="70" width="25" height="25" fill="currentColor" />
                    <rect x="10" y="75" width="15" height="15" fill="white" />
                    {/* Mock patterns */}
                    <rect x="40" y="10" width="10" height="10" fill="currentColor" />
                    <rect x="45" y="25" width="15" height="10" fill="currentColor" />
                    <rect x="55" y="5" width="8" height="8" fill="currentColor" />
                    <rect x="35" y="45" width="25" height="15" fill="currentColor" />
                    <rect x="75" y="45" width="15" height="15" fill="currentColor" />
                    <rect x="45" y="75" width="20" height="20" fill="currentColor" />
                    <rect x="75" y="75" width="15" height="20" fill="currentColor" />
                  </svg>
                </div>
                <div>
                  <h4 className={`text-sm font-bold text-emerald-900 ${lang === 'ur' ? 'font-urdu' : ''}`}>
                    {lang === 'ur' ? 'اسکین برائے فوری عطیہ' : 'Scan to Donate Instantly'}
                  </h4>
                  <p className="text-[11px] text-slate-500 leading-relaxed mt-1">
                    {lang === 'ur' ? 'اپنے فون کے کسی بھی یو ٹی آئی ایپ (بھارت پے، فون پے، گوگل پے) سے بس کوڈ اسکین کریں۔' : 'Utilize any UPI application to secure instantaneous, free of cost fund transfers.'}
                  </p>
                </div>
              </div>
            </div>

            <div className="text-center pt-4 border-t border-slate-100 text-[10px] text-slate-400 mt-4">
              All contributions are safe & governed by regulatory audits.
            </div>
          </div>
        </div>
      </section>

      {/* Announcements Timeline Section */}
      <section id="announcements" className="py-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16">
        
        <div className="text-center max-w-3xl mx-auto space-y-3">
          <span className="text-emerald-600 dark:text-emerald-400 text-sm font-bold uppercase tracking-widest block">
            {lang === 'ur' ? 'تازہ ترین واقعات و پروگرامز' : 'Timeline Notices'}
          </span>
          <h2 className={`text-3xl sm:text-5xl font-extrabold text-slate-900 dark:text-white ${lang === 'ur' ? 'font-urdu leading-snug' : 'tracking-tight'}`}>
            {t.announcementsTitle}
          </h2>
          <p className="text-slate-500 dark:text-slate-400 text-xs sm:text-sm">
            {lang === 'ur' ? 'سرگرمیوں پر مشتمل تحریری اطلاعاتِ جدید' : 'Fresh occurrences and religious schedules from Darul Uloom'}
          </p>
          <div className="w-24 h-1.5 bg-gradient-to-r from-emerald-600 to-amber-500 mx-auto rounded-full mt-4" />
        </div>

        <div className="max-w-4xl mx-auto space-y-6">
          {announcements.map((ann, index) => (
            <div
              key={ann.id}
              className={`rounded-3xl p-6 sm:p-8 border bg-white dark:bg-slate-900 shadow-sm relative overflow-hidden transition-all duration-300 ${
                ann.isImportant
                  ? 'border-amber-400/30 bg-gradient-to-tr from-amber-500/[0.02] to-transparent ring-2 ring-amber-500/5'
                  : 'border-slate-150 dark:border-slate-800'
              }`}
            >
              <div className="flex flex-col sm:flex-row justify-between items-start gap-4">
                
                <div className="space-y-3 flex-1">
                  
                  {/* Custom Indicator header row */}
                  <div className="flex flex-wrap items-center gap-2.5">
                    <span className="text-[11px] font-mono text-slate-500 bg-slate-100 dark:bg-slate-800 px-2.5 py-1 rounded-md flex items-center gap-1.5 border border-slate-200/50 dark:border-slate-700">
                      <Calendar className="w-3 h-3 text-slate-400" />
                      {ann.date}
                    </span>
                    
                    {ann.isImportant && (
                      <span className="bg-amber-500/10 text-amber-600 dark:text-amber-400 text-[10px] uppercase font-black tracking-widest px-2.5 py-1 rounded-md border border-amber-500/30">
                        {lang === 'ur' ? 'فوری خبر' : 'HIGH PRIORITY'}
                      </span>
                    )}
                  </div>

                  <p className={`text-slate-700 dark:text-slate-200 text-sm sm:text-base leading-relaxed ${lang === 'ur' ? 'font-urdu text-[15px] leading-loose' : ''}`}>
                    {lang === 'ur' ? ann.textUr : ann.textEn}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="bg-slate-100 dark:bg-slate-900 border-t border-b border-slate-200 dark:border-slate-800 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16">
          
          <div className="text-center max-w-3xl mx-auto space-y-3">
            <span className="text-amber-600 dark:text-amber-400 text-sm font-bold uppercase tracking-widest block">
              {lang === 'ur' ? 'مخلصینِ جامعہ کی آراء' : 'Reflections & Praise'}
            </span>
            <h2 className={`text-3xl sm:text-5xl font-extrabold text-slate-900 dark:text-white ${lang === 'ur' ? 'font-urdu leading-snug' : 'tracking-tight'}`}>
              {t.testimonialsTitle}
            </h2>
            <p className="text-slate-500 dark:text-slate-400 text-xs sm:text-sm">
              {t.testimonialsSubtitle}
            </p>
            <div className="w-24 h-1.5 bg-gradient-to-r from-emerald-600 to-amber-500 mx-auto rounded-full mt-4" />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map((test) => (
              <div
                key={test.id}
                className="bg-white dark:bg-slate-800 border border-slate-150 dark:border-slate-750 rounded-3xl p-6 sm:p-8 shadow-sm flex flex-col justify-between hover:shadow-md transition relative group"
              >
                {/* Visual quote mark watermark to elevate look */}
                <span className="absolute top-4 right-4 text-slate-100 dark:text-slate-850 text-5xl font-serif pointer-events-none group-hover:scale-110 transition">
                  ”
                </span>

                <div className="space-y-4 relative z-10 text-left">
                  {/* Multi-Stars Rating row */}
                  <div className="flex gap-1">
                    {[...Array(5)].map((_, i) => (
                      <span key={i} className="text-amber-500 text-sm">★</span>
                    ))}
                  </div>

                  <p className={`text-slate-600 dark:text-slate-300 text-xs sm:text-sm leading-relaxed ${lang === 'ur' ? 'font-urdu text-right text-[13px] leading-loose' : 'font-sans'}`}>
                    {lang === 'ur' ? test.quoteUr : test.quoteEn}
                  </p>
                </div>

                <div className="pt-6 border-t border-slate-50 dark:border-slate-750 mt-6 flex items-center justify-between text-left">
                  <div>
                    <h4 className={`text-sm sm:text-base font-extrabold text-slate-800 dark:text-slate-100 ${lang === 'ur' ? 'font-urdu text-right' : 'font-sans'}`}>
                      {lang === 'ur' ? test.authorUr : test.authorEn}
                    </h4>
                    <span className={`text-[10px] text-emerald-600 dark:text-emerald-400 block ${lang === 'ur' ? 'font-urdu text-right mt-1' : 'uppercase tracking-wider font-mono'}`}>
                      {lang === 'ur' ? test.roleUr : test.roleEn}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16">
        
        <div className="text-center max-w-3xl mx-auto space-y-3">
          <span className="text-emerald-600 dark:text-emerald-400 text-sm font-bold uppercase tracking-widest block">
            {lang === 'ur' ? 'داخلہ و عطیات کے لیے معلومات' : 'Enquiries Desk'}
          </span>
          <h2 className={`text-3xl sm:text-5xl font-extrabold text-slate-900 dark:text-white ${lang === 'ur' ? 'font-urdu leading-snug' : 'tracking-tight'}`}>
            {t.contactTitle}
          </h2>
          <p className="text-slate-500 dark:text-slate-400 text-xs sm:text-sm">
            {t.contactSubtitle}
          </p>
          <div className="w-24 h-1.5 bg-gradient-to-r from-emerald-600 to-amber-500 mx-auto rounded-full mt-4" />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-stretch">
          
          {/* Contact Left: General Address info & Interactive Maps */}
          <div className="lg:col-span-5 space-y-6 flex flex-col justify-between">
            <div className="space-y-6">
              
              <div className="flex gap-4 items-start text-left">
                <div className="p-3.5 bg-emerald-50 dark:bg-emerald-950/40 rounded-2xl text-emerald-800 dark:text-emerald-300 flex-shrink-0">
                  <MapPin className="w-6 h-6" />
                </div>
                <div>
                  <h4 className="text-xs text-slate-400 uppercase font-mono tracking-wider">{t.addressLabel}</h4>
                  <p className={`text-sm sm:text-base font-bold text-slate-800 dark:text-slate-200 mt-1 ${lang === 'ur' ? 'font-urdu text-right' : ''}`}>
                    {lang === 'ur' ? 'تاج نگر ہاویری-581110، کرناٹک، انڈیا' : 'Taj Nagar, Haveri-581110, Karnataka, India'}
                  </p>
                </div>
              </div>

              <div className="flex gap-4 items-start text-left">
                <div className="p-3.5 bg-emerald-50 dark:bg-emerald-950/40 rounded-2xl text-emerald-800 dark:text-emerald-300 flex-shrink-0">
                  <Phone className="w-6 h-6" />
                </div>
                <div>
                  <h4 className="text-xs text-slate-400 uppercase font-mono tracking-wider">{t.phoneLabel}</h4>
                  <a href="tel:+919450884954" className="text-sm sm:text-base font-extrabold text-emerald-700 dark:text-emerald-400 hover:underline block mt-1">
                    +91 94508 84954
                  </a>
                  <a href="tel:+918550012786" className="text-sm sm:text-base font-extrabold text-emerald-700 dark:text-emerald-400 hover:underline block">
                    +91 85500 12786
                  </a>
                </div>
              </div>

              <div className="flex gap-4 items-start text-left">
                <div className="p-3.5 bg-emerald-50 dark:bg-emerald-950/40 rounded-2xl text-emerald-800 dark:text-emerald-300 flex-shrink-0">
                  <Mail className="w-6 h-6" />
                </div>
                <div>
                  <h4 className="text-xs text-slate-400 uppercase font-mono tracking-wider">{t.emailLabel}</h4>
                  {/* Using user's shared email as requested in metadata */}
                  <a href="mailto:asskhazi@gmail.com" className="text-sm sm:text-base font-bold text-slate-800 dark:text-slate-100 hover:underline block mt-1">
                    asskhazi@gmail.com
                  </a>
                </div>
              </div>

            </div>

            {/* Simulated Interactive Map with Roadmap/Satellite Switch */}
            <div className="rounded-3xl border border-slate-200 dark:border-slate-850 p-4 bg-white dark:bg-slate-900 shadow-sm space-y-3">
              <div className="flex items-center justify-between text-xs font-semibold">
                <span className="text-slate-500 flex items-center gap-1.5">
                  <MapPin className="w-4 h-4 text-emerald-600" />
                  <span>Google Map Positioning</span>
                </span>
                
                {/* Interactive Map view selector toggle */}
                <div className="flex gap-1 bg-slate-100 dark:bg-slate-800 rounded-lg p-0.5 border border-slate-200 dark:border-slate-700">
                  <button 
                    onClick={() => setMapType('roadmap')}
                    className={`px-2.5 py-1 rounded text-[10px] cursor-pointer ${mapType === 'roadmap' ? 'bg-white dark:bg-slate-950 font-bold shadow-sm' : 'text-slate-400'}`}
                  >
                    Roadmap
                  </button>
                  <button 
                    onClick={() => setMapType('satellite')}
                    className={`px-2.5 py-1 rounded text-[10px] cursor-pointer ${mapType === 'satellite' ? 'bg-white dark:bg-slate-950 font-bold shadow-sm' : 'text-slate-400'}`}
                  >
                    Satellite
                  </button>
                </div>
              </div>

              {/* Map Canvas Frame Area (Aesthetically designed placeholder which replicates deep coordinates) */}
              <div className="w-full h-44 rounded-2xl overflow-hidden relative border border-slate-200 dark:border-slate-800">
                {mapType === 'roadmap' ? (
                  <div className="absolute inset-0 bg-[#e5e9f0] dark:bg-[#1a2333] flex flex-col items-center justify-center p-4 text-center">
                    {/* SVG Roadmap Grid */}
                    <svg viewBox="0 0 200 100" className="w-full h-full opacity-20 absolute inset-0">
                      <line x1="0" y1="20" x2="200" y2="20" stroke="currentColor" strokeWidth="2" />
                      <line x1="0" y1="60" x2="200" y2="60" stroke="currentColor" strokeWidth="2" />
                      <line x1="40" y1="0" x2="40" y2="100" stroke="currentColor" strokeWidth="2" />
                      <line x1="120" y1="0" x2="120" y2="100" stroke="currentColor" strokeWidth="2" />
                    </svg>
                    <div className="relative z-10 space-y-1 text-slate-700 dark:text-slate-300">
                      <span className="font-extrabold text-xs block text-emerald-800 dark:text-emerald-400">DARUL ULOOM RAZA-E-GOUS-E-AZAM</span>
                      <span className="text-[10px] text-slate-500 block">Taj Nagar, Haveri Karnataka 581110</span>
                      <a 
                        href="https://maps.google.com/?q=Taj+Nagar,+Haveri,+Karnataka"
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1.5 mt-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold px-3 py-1 rounded text-[10px] shadow-sm transition"
                      >
                        <span>Open on Native Map</span>
                        <ExternalLink className="w-3 h-3" />
                      </a>
                    </div>
                  </div>
                ) : (
                  <div className="absolute inset-0 bg-[#0c1020] flex flex-col items-center justify-center p-4 text-center">
                    {/* Satellite Mock Vector */}
                    <div className="absolute inset-0 bg-[radial-gradient(#15803d_1.5px,transparent_1.5px)] [background-size:20px_20px] opacity-25" />
                    <div className="relative z-10 space-y-1 text-emerald-200">
                      <span className="font-mono text-[9px] text-slate-500 uppercase block">Satellite Coordinates: 14.7932° N, 75.3971° E</span>
                      <span className="font-bold text-xs block">Emerald Dome Canopy Highlight (Taj Nagar)</span>
                      <a 
                        href="https://maps.google.com/?q=Taj+Nagar,+Haveri,+Karnataka"
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1.5 mt-2 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold px-3 py-1 rounded text-[10px] shadow-sm transition"
                      >
                        <span>Launch Coordinates</span>
                        <ExternalLink className="w-3 h-3" />
                      </a>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Contact Right: Interactive Form With Verification feedback */}
          <div className="lg:col-span-7 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 sm:p-8 shadow-sm">
            <h3 className={`text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white mb-2 ${lang === 'ur' ? 'font-urdu' : ''}`}>
              {t.contactFormTitle}
            </h3>
            
            <p className="text-slate-500 dark:text-slate-400 text-xs sm:text-sm mb-6">
              {lang === 'ur' ? 'فارم پُر کریں، مینیجر آپ سے فون کال یا واٹس ایپ پر چوبیس گھنٹے میں رابطہ کرے گا۔' : 'Fill details below so that our correspondent will get back in touch with your family.'}
            </p>

            <form onSubmit={handleContactSubmit} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-[11px] font-bold text-slate-450 dark:text-slate-400 uppercase tracking-wider block">
                    {lang === 'ur' ? 'آپ کا مبارک نام (لازمی)' : 'Your Full Name (Required)'}
                  </label>
                  <input
                    type="text"
                    required
                    value={contactForm.name}
                    onChange={(e) => setContactForm({ ...contactForm, name: e.target.value })}
                    className="w-full bg-slate-50 dark:bg-slate-850 border border-slate-200 dark:border-slate-750 px-4 py-3 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 text-sm"
                    placeholder={t.contactNamePlaceholder}
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-[11px] font-bold text-slate-450 dark:text-slate-400 uppercase tracking-wider block">
                    {lang === 'ur' ? 'موبائل نمبر (لازمی)' : 'Phone Number (Required)'}
                  </label>
                  <input
                    type="tel"
                    required
                    value={contactForm.phone}
                    onChange={(e) => setContactForm({ ...contactForm, phone: e.target.value })}
                    className="w-full bg-slate-50 dark:bg-slate-850 border border-slate-200 dark:border-slate-750 px-4 py-3 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 text-sm"
                    placeholder={t.contactPhonePlaceholder}
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-[11px] font-bold text-slate-450 dark:text-slate-400 uppercase tracking-wider block">
                  {lang === 'ur' ? 'ای میل پتہ (اختیاری)' : 'Email Address (Optional)'}
                </label>
                <input
                  type="email"
                  value={contactForm.email}
                  onChange={(e) => setContactForm({ ...contactForm, email: e.target.value })}
                  className="w-full bg-slate-50 dark:bg-slate-850 border border-slate-200 dark:border-slate-750 px-4 py-3 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 text-sm"
                  placeholder={t.contactEmailPlaceholder}
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-[11px] font-bold text-slate-450 dark:text-slate-400 uppercase tracking-wider block">
                  {lang === 'ur' ? 'پیغام / سوال / شعبہ (لازمی)' : 'Your Inquiry or Message (Required)'}
                </label>
                <textarea
                  required
                  rows={4}
                  value={contactForm.message}
                  onChange={(e) => setContactForm({ ...contactForm, message: e.target.value })}
                  className="w-full bg-slate-50 dark:bg-slate-850 border border-slate-200 dark:border-slate-750 px-4 py-3 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 text-sm"
                  placeholder={t.contactMsgPlaceholder}
                />
              </div>

              {formSubmitted ? (
                <div className="bg-emerald-50 dark:bg-emerald-950/20 border border-emerald-500/20 text-emerald-800 dark:text-emerald-300 rounded-xl p-4 text-center font-bold text-xs sm:text-sm">
                  ✓ {lang === 'ur' ? 'بہت شکریہ! آپ کا فارم موصول ہوگیا ہے اور ہم جلد از جلد رابطہ فرمائیں گے۔' : 'Thank you! Your inquiry was dispatched. Our administrator will review it today.'}
                </div>
              ) : (
                <button
                  type="submit"
                  className="w-full bg-emerald-700 hover:bg-emerald-800 text-white font-bold py-3.5 px-6 rounded-xl shadow-md cursor-pointer transition text-center text-sm"
                >
                  <span className={lang === 'ur' ? 'font-urdu' : ''}>{t.contactSubmitBtn}</span>
                </button>
              )}
            </form>
          </div>
        </div>
      </section>

      {/* Footer Section */}
      <footer className="bg-slate-950 text-white pt-16 pb-8 border-t border-slate-900 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-4 gap-12 text-left">
          
          {/* Logo Brand Tagline col */}
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-full bg-amber-500 flex items-center justify-center text-slate-950 font-bold text-xs">
                ⭐
              </div>
              <div>
                <h4 className={`font-black text-amber-400 ${lang === 'ur' ? 'font-urdu text-sm' : 'text-xs'}`}>
                  {t.schoolName}
                </h4>
                <span className="text-[10px] text-slate-400 font-mono">{t.regNumber}</span>
              </div>
            </div>
            
            <p className={`text-slate-400 text-xs leading-relaxed ${lang === 'ur' ? 'font-urdu' : ''}`}>
              {t.footerTagline}
            </p>
          </div>

          {/* Quick Sections col */}
          <div className="space-y-4">
            <h4 className={`text-sm font-bold uppercase tracking-wider text-amber-400 ${lang === 'ur' ? 'font-urdu' : ''}`}>{t.quickLinks}</h4>
            <div className="flex flex-col gap-2.5 text-xs text-slate-400">
              <button onClick={() => scrollToSection('about')} className="text-left hover:text-white transition cursor-pointer">{t.navAbout}</button>
              <button onClick={() => scrollToSection('courses')} className="text-left hover:text-white transition cursor-pointer">{t.navCourses}</button>
              <button onClick={() => scrollToSection('facilities')} className="text-left hover:text-white transition cursor-pointer">{t.navFacilities}</button>
              <button onClick={() => scrollToSection('gallery')} className="text-left hover:text-white transition cursor-pointer">{t.navGallery}</button>
              <button onClick={() => scrollToSection('documents')} className="text-left hover:text-white transition cursor-pointer">{t.navDocuments}</button>
              <button onClick={() => scrollToSection('donation')} className="text-left hover:text-amber-300 text-amber-400 transition cursor-pointer">{t.navDonation}</button>
              <button onClick={() => scrollToSection('contact')} className="text-left hover:text-white transition cursor-pointer">{t.navContact}</button>
            </div>
          </div>

          {/* Location details */}
          <div className="space-y-4 md:col-span-2">
            <h4 className="text-xs uppercase tracking-widest text-amber-400 font-bold">Principal Office Contact</h4>
            <div className="space-y-3 text-slate-400 text-xs">
              <p className="flex items-center gap-2">
                <MapPin className="w-4 h-4 text-emerald-500 flex-shrink-0" />
                <span>Taj Nagar, Haveri-581110, Karnataka, India</span>
              </p>
              <p className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-emerald-500 flex-shrink-0" />
                <span>+91 94508 84954, +91 85500 12786</span>
              </p>
              <p className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-emerald-500 flex-shrink-0" />
                <span className="underline">asskhazi@gmail.com</span>
              </p>
              
              {/* Spiritual signature pray statement */}
              <div className="pt-3 border-t border-slate-900">
                <p className={`text-amber-500/80 leading-loose ${lang === 'ur' ? 'font-urdu text-[12px]' : 'italic font-serif'}`}>
                  {lang === 'ur' 
                    ? 'اللہ تعالیٰ جامعہ مخلصین و معطینِ نیک کے صدقات و خیرات کو قبول فرمائے۔ آمین بجاہ النبی الکریم صلّی اللہ تعالیٰ علیہ وسلّم۔' 
                    : 'May Allah accept the support and spiritual donations of all patrons of this holy cause. Ameen.'
                  }
                </p>
              </div>
            </div>
          </div>

        </div>

        {/* Down Copyright row */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 border-t border-slate-900 mt-12 pt-6 text-center text-xs text-slate-500 flex flex-col sm:flex-row justify-between items-center gap-4">
          <p>© {new Date().getFullYear()} Darul Uloom Raza-E-Gous-E-Azam, Haveri, Karnataka. All Rights Reserved.</p>
          <div className="flex gap-4">
            <a href="tel:+919450884954" className="hover:text-slate-300">Call</a>
            <a href="https://wa.me/919450884954" className="hover:text-slate-300">WhatsApp</a>
            <button onClick={() => setDarkMode(!darkMode)} className="hover:text-slate-300 cursor-pointer">Theme Toggle</button>
          </div>
        </div>
      </footer>

      {/* Sticky Back-to-Top Anchor Widget */}
      <AnimatePresence>
        {showScrollTop && (
          <motion.button
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.8 }}
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
            className="fixed bottom-6 left-6 p-3.5 rounded-full bg-emerald-700 hover:bg-emerald-800 text-white shadow-xl cursor-pointer z-40 border border-amber-400"
            title="Back to Top / اوپر جائیں"
          >
            <ChevronUp className="w-6 h-6 animate-bounce" />
          </motion.button>
        )}
      </AnimatePresence>

    </div>
  );
}
